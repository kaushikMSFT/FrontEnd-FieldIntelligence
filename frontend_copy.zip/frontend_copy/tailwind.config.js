/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // Leave Manager theme tokens (PRD Section 3)
        'navy-dark': '#0B1F44',      // sidebar, primary buttons, selected states
        'navy-text': '#16213E',      // primary text
        'indigo-accent': '#5B4B9A',  // section headings (LEAVE, FLEXIBLE HOLIDAY style)
        'teal-accent': '#0FB59A',    // key metrics, positive/ready states
        'page-bg': '#F4F5F9',        // canvas behind cards
        'muted-border': '#9CA3AF',   // Exception card accent (Section 6 design)
        'muted-text': '#6B7280',     // secondary text
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
      },
    },
  },
  plugins: [],
}