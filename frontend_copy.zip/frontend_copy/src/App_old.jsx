import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Stethoscope } from 'lucide-react'
import { useAuthStore } from './store/authStore'
import { fetchDoctors } from './api/client'
import LoginScreen from './components/LoginScreen'
import LandingPage from './components/LandingPage'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import DoctorAccordion from './components/DoctorAccordion'
import NudgePopover from './components/NudgePopover'
import TourPlanPage from './components/TourPlanPage'
import DoctorListPage from './components/DoctorListPage'
import LearnPage from './components/LearnPage'
import SalesIQPage from './components/SalesIQPage'
import ProductInfoPage from './components/ProductInfoPage'
import SettingsPage from './components/SettingsPage'
import AdminPanel from './components/AdminPanel'

export default function App() {
  const role = useAuthStore((s) => s.role)
  const [showLogin, setShowLogin] = useState(false)

  if (!role) {
    return showLogin ? <LoginScreen /> : <LandingPage onGetStarted={() => setShowLogin(true)} />
  }

  // The 5-tab sidebar (Doctor List / Learn / Next Best Action / Sales IQ /
  // Settings) is MR-only navigation. Super Admin gets a completely separate,
  // simpler view — just the Admin Panel, same as before this nav existed.
  return role === 'admin' ? <AdminApp /> : <MRApp />
}

function MRApp() {
  const [activeSection, setActiveSection] = useState('next_best_action')
  const [nudgeDoctor, setNudgeDoctor] = useState(null) // doctor object, or null when popover closed

  return (
    <div className="h-screen flex">
      <Sidebar activeSection={activeSection} onSelectSection={setActiveSection} />
      <div className="flex-1 flex flex-col min-w-0">
        <Header activeSection={activeSection} />
        <main className="flex-1 overflow-auto p-6">
          {activeSection === 'doctor_list' && <DoctorListPage />}
          {activeSection === 'learn' && <LearnPage />}
          {activeSection === 'next_best_action' && <NextBestActionPage onOpenNudge={setNudgeDoctor} />}
          {activeSection === 'tour_plan' && <TourPlanPage />}
          {activeSection === 'sales_iq' && <SalesIQPage />}
          {activeSection === 'product_info' && <ProductInfoPage />}
          {activeSection === 'settings' && <SettingsPage />}
        </main>
      </div>

      {nudgeDoctor && <NudgePopover doctor={nudgeDoctor} onClose={() => setNudgeDoctor(null)} />}
    </div>
  )
}

function AdminApp() {
  return (
    <div className="h-screen flex">
      <aside className="w-56 bg-navy-dark text-white flex flex-col shrink-0">
        <div className="px-5 py-6 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Stethoscope size={22} />
            <span className="font-bold text-lg">Field Intelligence</span>
          </div>
        </div>
      </aside>
      <div className="flex-1 flex flex-col min-w-0">
        <Header activeSection="settings" />
        <main className="flex-1 overflow-auto p-6">
          <AdminPanel />
        </main>
      </div>
    </div>
  )
}

function NextBestActionPage({ onOpenNudge }) {
  const { data: doctors, isLoading, isError } = useQuery({
    queryKey: ['doctors'],
    queryFn: fetchDoctors,
  })

  if (isLoading) return <p className="text-sm text-muted-text">Loading doctors…</p>
  if (isError) return <p className="text-sm text-red-600">Couldn't load doctors. Is the backend running?</p>

  return <DoctorAccordion doctors={doctors} onOpenNudge={onOpenNudge} />
}