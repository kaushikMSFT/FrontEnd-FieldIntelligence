import { create } from 'zustand'

const STORAGE_KEY = 'visit_prep_session'

function loadStoredSession() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

const stored = loadStoredSession()

export const useAuthStore = create((set) => ({
  role: stored?.role || null,
  sessionToken: stored?.sessionToken || null,
  username: stored?.username || null,

  setSession: (role, sessionToken, username) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ role, sessionToken, username }))
    set({ role, sessionToken, username })
  },

  clearSession: () => {
    localStorage.removeItem(STORAGE_KEY)
    set({ role: null, sessionToken: null, username: null })
  },
}))