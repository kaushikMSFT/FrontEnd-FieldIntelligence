import { useState } from 'react'
import { useQuery, useMutation } from '@tanstack/react-query'
import ReactMarkdown from 'react-markdown'
import { MessageCircle, Send, AlertCircle, Loader2 } from 'lucide-react'
import { fetchIngestedDrugs, askPIQuestion } from '../api/client'

export default function ProductChatPanel() {
  const [selectedDrug, setSelectedDrug] = useState('')
  const [messages, setMessages] = useState([]) // {role: 'user'|'assistant', text}[] -- in-memory only, per agreed scope
  const [question, setQuestion] = useState('')

  const { data: drugs, isLoading: drugsLoading } = useQuery({
    queryKey: ['ingestedDrugs'],
    queryFn: fetchIngestedDrugs,
  })

  const askMutation = useMutation({
    mutationFn: ({ drug, q }) => askPIQuestion(drug, q),
    onSuccess: (response) => {
      const answerText = Array.isArray(response.answer) ? response.answer.join(' ') : response.answer
      setMessages((m) => [...m, { role: 'assistant', text: answerText || "I couldn't find an answer." }])
    },
    onError: (e) => {
      setMessages((m) => [...m, { role: 'error', text: e.message }])
    },
  })

  function handleDrugChange(drug) {
    setSelectedDrug(drug)
    setMessages([]) // switching drugs starts a fresh conversation
  }

  function handleSubmit(e) {
    e.preventDefault()
    const q = question.trim()
    if (!q || !selectedDrug) return
    setMessages((m) => [...m, { role: 'user', text: q }])
    setQuestion('')
    askMutation.mutate({ drug: selectedDrug, q })
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm flex flex-col h-full">
      <div className="px-4 py-3 border-b border-gray-100">
        <div className="flex items-center gap-1.5 mb-2">
          <MessageCircle size={13} className="text-indigo-accent" />
          <h3 className="text-xs font-semibold uppercase tracking-wide text-indigo-accent">Ask About a Product</h3>
        </div>
        <select
          value={selectedDrug}
          onChange={(e) => handleDrugChange(e.target.value)}
          disabled={drugsLoading}
          className="w-full text-sm border border-gray-200 rounded-full px-3.5 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
        >
          <option value="">
            {drugsLoading ? 'Loading…' : (drugs || []).length === 0 ? 'No ingested documents yet' : 'Select a drug…'}
          </option>
          {(drugs || []).map((d) => (
            <option key={d} value={d}>
              {d}
            </option>
          ))}
        </select>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-[200px]">
        {!selectedDrug && (
          <p className="text-sm text-muted-text text-center py-8">
            Select a drug above to start asking questions about its Product Information.
          </p>
        )}

        {selectedDrug && messages.length === 0 && (
          <p className="text-sm text-muted-text text-center py-8">Ask anything about {selectedDrug}'s Product Information.</p>
        )}

        {messages.map((m, i) => (
          <ChatBubble key={i} message={m} />
        ))}

        {askMutation.isPending && (
          <div className="flex items-center gap-2 text-sm text-muted-text">
            <Loader2 size={14} className="animate-spin" />
            Thinking…
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="p-3 border-t border-gray-100 flex items-end gap-2">
        <textarea
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder={selectedDrug ? 'Ask a question…' : 'Select a drug first'}
          disabled={!selectedDrug || askMutation.isPending}
          rows={1}
          className="flex-1 text-sm border border-gray-200 rounded-md px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-accent/30 resize-none disabled:opacity-60"
        />
        <button
          type="submit"
          disabled={!selectedDrug || !question.trim() || askMutation.isPending}
          className="flex items-center justify-center w-9 h-9 rounded-full bg-navy-dark text-white hover:opacity-90 transition disabled:opacity-50 shrink-0"
        >
          <Send size={14} />
        </button>
      </form>
    </div>
  )
}

function ChatBubble({ message }) {
  if (message.role === 'user') {
    return (
      <div className="flex justify-end">
        <div className="max-w-[85%] bg-navy-dark text-white text-sm rounded-lg rounded-br-sm px-3 py-2">{message.text}</div>
      </div>
    )
  }
  if (message.role === 'error') {
    return (
      <div className="flex items-start gap-2 bg-red-50 border border-red-100 rounded-md px-3 py-2">
        <AlertCircle size={13} className="text-red-600 shrink-0 mt-0.5" />
        <p className="text-sm text-red-700">{message.text}</p>
      </div>
    )
  }
  return (
    <div className="flex justify-start">
      <div className="max-w-[85%] bg-gray-50 text-navy-text text-sm rounded-lg rounded-bl-sm px-3 py-2">
        <ReactMarkdown
          components={{
            p: ({ children }) => <p className="whitespace-pre-wrap leading-relaxed mb-1.5 last:mb-0">{children}</p>,
            strong: ({ children }) => <strong className="font-semibold text-navy-text">{children}</strong>,
            em: ({ children }) => <em className="italic">{children}</em>,
            ul: ({ children }) => <ul className="list-disc pl-4 space-y-0.5 mb-1.5">{children}</ul>,
            ol: ({ children }) => <ol className="list-decimal pl-4 space-y-0.5 mb-1.5">{children}</ol>,
            li: ({ children }) => <li className="leading-relaxed">{children}</li>,
            a: ({ children, href }) => (
              <a href={href} target="_blank" rel="noreferrer" className="text-indigo-accent underline">
                {children}
              </a>
            ),
            code: ({ children }) => <code className="bg-gray-100 rounded px-1 py-0.5 text-xs">{children}</code>,
          }}
        >
          {message.text}
        </ReactMarkdown>
      </div>
    </div>
  )
}