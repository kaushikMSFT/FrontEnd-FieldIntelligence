import { useMemo, useState } from 'react'
import { ChevronDown, Bell, Mail, Calendar, Clock, Hash, Megaphone, Stethoscope } from 'lucide-react'
import StatusBadge from './StatusBadge'

export default function DoctorAccordion({ doctors, onOpenNudge }) {
  const [expandedHcpId, setExpandedHcpId] = useState(null)
  const [specialtyFilter, setSpecialtyFilter] = useState('all')
  const [search, setSearch] = useState('')
  const [sortAsc, setSortAsc] = useState(true) // default: ascending by priority

  const specialties = useMemo(
    () => [...new Set(doctors.map((d) => d.specialty).filter(Boolean))].sort(),
    [doctors]
  )

  const filteredSorted = useMemo(() => {
    let list = doctors.filter((d) => {
      const matchesSpecialty = specialtyFilter === 'all' || d.specialty === specialtyFilter
      const matchesSearch = d.name.toLowerCase().includes(search.toLowerCase())
      return matchesSpecialty && matchesSearch
    })
    list = [...list].sort((a, b) => (sortAsc ? a.priority - b.priority : b.priority - a.priority))
    return list
  }, [doctors, specialtyFilter, search, sortAsc])

  return (
    <div className="max-w-3xl">
      <div className="flex items-center gap-3 mb-4">
        <input
          type="text"
          placeholder="Search doctors…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="flex-1 max-w-xs text-sm border border-gray-200 rounded-md px-3 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
        />
        <select
          value={specialtyFilter}
          onChange={(e) => setSpecialtyFilter(e.target.value)}
          className="text-sm border border-gray-200 rounded-md px-3 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
        >
          <option value="all">All specialties</option>
          {specialties.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <button
          onClick={() => setSortAsc((v) => !v)}
          className="text-sm text-muted-text hover:text-navy-text px-2 py-1.5 transition"
        >
          Priority {sortAsc ? '↑' : '↓'}
        </button>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm max-h-[65vh] overflow-y-auto p-3 space-y-2">
        {filteredSorted.map((doctor) => (
          <AccordionItem
            key={doctor.hcp_id}
            doctor={doctor}
            isExpanded={expandedHcpId === doctor.hcp_id}
            onToggle={() => setExpandedHcpId((cur) => (cur === doctor.hcp_id ? null : doctor.hcp_id))}
            onOpenNudge={() => onOpenNudge(doctor)}
          />
        ))}

        {filteredSorted.length === 0 && (
          <div className="px-4 py-8 text-center text-sm text-muted-text">No doctors match your filters.</div>
        )}
      </div>
    </div>
  )
}

function AccordionItem({ doctor, isExpanded, onToggle, onOpenNudge }) {
  const isException = doctor.status === 'exception'

  return (
    <div
      className={`rounded-lg border overflow-hidden transition ${
        isException ? 'bg-red-50/40 border-red-200' : 'bg-green-50/40 border-green-200'
      }`}
      style={{ borderLeftWidth: '4px', borderLeftColor: isException ? '#DC2626' : '#16A34A' }}
    >
      <button
        onClick={onToggle}
        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-black/[0.02] transition"
      >
        <ChevronDown
          size={16}
          className={`text-muted-text shrink-0 transition-transform ${isExpanded ? 'rotate-180' : ''}`}
        />
        {!isException && <span className="w-2 h-2 rounded-full bg-green-500 shrink-0" title="Nudge available" />}

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className={`font-medium ${isException ? 'text-muted-text' : 'text-navy-text'}`}>
              {doctor.name}
            </span>
            {doctor.priority !== 1 && (
              <span className="text-xs text-muted-text shrink-0">Priority {doctor.priority}</span>
            )}
          </div>
          {doctor.specialty && (
            <span className="flex items-center gap-1 text-xs text-muted-text mt-0.5">
              <Stethoscope size={11} />
              {doctor.specialty}
            </span>
          )}
          <DaysSinceVisit lastMeetingDate={doctor.last_meeting_date} />
        </div>

        <StatusBadge status={doctor.status} />
        <button
          onClick={(e) => {
            e.stopPropagation()
            onOpenNudge()
          }}
          title={isException ? 'Check for a recommendation' : 'View nudge'}
          className={`p-1.5 rounded-full transition ${
            isException
              ? 'text-muted-text hover:bg-gray-100'
              : 'text-indigo-accent hover:bg-indigo-accent/10'
          }`}
        >
          <Bell size={16} />
        </button>
      </button>

      {isExpanded && (
        <div className="px-4 pb-4 pt-1 border-t border-gray-100 bg-white">
          <dl className="space-y-2 text-sm mb-3">
            <div className="flex items-center gap-2.5 text-navy-text">
              <Hash size={14} className="text-muted-text shrink-0" />
              <span className="text-muted-text w-24 shrink-0">HCP ID</span>
              <span className="font-medium">{doctor.hcp_id}</span>
            </div>
            {doctor.email_address && (
              <div className="flex items-center gap-2.5 text-navy-text">
                <Mail size={14} className="text-muted-text shrink-0" />
                <span className="text-muted-text w-24 shrink-0">Email</span>
                <span className="font-medium">{doctor.email_address}</span>
              </div>
            )}
            {doctor.next_visit_date && (
              <div className="flex items-center gap-2.5 text-navy-text">
                <Calendar size={14} className="text-muted-text shrink-0" />
                <span className="text-muted-text w-24 shrink-0">Next visit</span>
                <span className="font-medium">{doctor.next_visit_date}</span>
              </div>
            )}
            {doctor.next_visit_timeslot && (
              <div className="flex items-center gap-2.5 text-navy-text">
                <Clock size={14} className="text-muted-text shrink-0" />
                <span className="text-muted-text w-24 shrink-0">Timeslot</span>
                <span className="font-medium">{doctor.next_visit_timeslot}</span>
              </div>
            )}
          </dl>

          {isException && (
            <p className="text-xs text-muted-text mb-3">
              No history of your own with this doctor yet — click the bell to check whether a recommendation
              based on similar doctors is available.
            </p>
          )}
          <button
            onClick={onOpenNudge}
            className="flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-full bg-navy-dark text-white hover:opacity-90 transition"
          >
            <Megaphone size={14} />
            {isException ? 'Check for recommendation' : 'View nudge'}
          </button>
        </div>
      )}
    </div>
  )
}

function DaysSinceVisit({ lastMeetingDate }) {
  if (!lastMeetingDate) {
    return (
      <span className="flex items-center gap-1 text-xs text-muted-text mt-0.5">
        <Clock size={11} />
        No visits yet
      </span>
    )
  }

  const days = Math.floor((Date.now() - new Date(lastMeetingDate).getTime()) / (1000 * 60 * 60 * 24))
  const colorClass = days >= 90 ? 'text-red-600' : days >= 45 ? 'text-amber-600' : 'text-muted-text'

  return (
    <span className={`flex items-center gap-1 text-xs mt-0.5 ${colorClass}`}>
      <Clock size={11} />
      {days}d since last visit
    </span>
  )
}