import { useMemo, useRef, useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Map, Upload, Loader2, AlertCircle, CheckCircle2, Users, X, Download } from 'lucide-react'
import {
  generateTourPlan,
  fetchTourPlanStatus,
  fetchTourPlanEntries,
  fetchLatestTourPlanRun,
  fetchDefaultMr,
  downloadTourPlanUrl,
} from '../api/client'

const DAY_ORDER = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

export default function TourPlanPage() {
  const queryClient = useQueryClient()
  const historyInputRef = useRef(null)
  const syntheticInputRef = useRef(null)
  const [historyFile, setHistoryFile] = useState(null)
  const [syntheticFile, setSyntheticFile] = useState(null)
  const [activeRunId, setActiveRunId] = useState(null)
  const [drillDown, setDrillDown] = useState(null) // { week, day } or null
  const [uploadError, setUploadError] = useState(null)

  const { data: defaultMr } = useQuery({ queryKey: ['tourPlanDefaultMr'], queryFn: fetchDefaultMr })

  const { data: latestRun } = useQuery({
    queryKey: ['tourPlanLatestRun'],
    queryFn: fetchLatestTourPlanRun,
    retry: false,
  })

  const runId = activeRunId ?? latestRun?.id ?? null

  const { data: runStatus } = useQuery({
    queryKey: ['tourPlanStatus', runId],
    queryFn: () => fetchTourPlanStatus(runId),
    enabled: !!runId,
    refetchInterval: (query) => (query.state.data?.status === 'generating' ? 2000 : false),
  })

  const { data: entries } = useQuery({
    queryKey: ['tourPlanEntries', runId],
    queryFn: () => fetchTourPlanEntries(runId),
    enabled: runStatus?.status === 'completed',
  })

  const generateMutation = useMutation({
    mutationFn: () => generateTourPlan(historyFile, syntheticFile, defaultMr),
    onSuccess: (run) => {
      setActiveRunId(run.id)
      setDrillDown(null)
      setUploadError(null)
      setHistoryFile(null)
      setSyntheticFile(null)
      if (historyInputRef.current) historyInputRef.current.value = ''
      if (syntheticInputRef.current) syntheticInputRef.current.value = ''
      queryClient.invalidateQueries({ queryKey: ['tourPlanStatus'] })
    },
    onError: (e) => setUploadError(e.message),
  })

  function handleSubmit(e) {
    e.preventDefault()
    setUploadError(null)
    generateMutation.mutate()
  }

  // Build the weekly grid: rows = week of month, columns = days present in
  // the data (in Mon-Sun order), cell = count of doctors for that slot.
  const { weeks, days, gridCounts } = useMemo(() => {
    if (!entries || entries.length === 0) return { weeks: [], days: [], gridCounts: {} }

    const weekSet = new Set()
    const daySet = new Set()
    const counts = {}

    for (const e of entries) {
      weekSet.add(e.week_of_month)
      daySet.add(e.day)
      const key = `${e.week_of_month}|${e.day}`
      counts[key] = (counts[key] || 0) + 1
    }

    const weeks = [...weekSet].sort((a, b) => a - b)
    const days = DAY_ORDER.filter((d) => daySet.has(d))

    return { weeks, days, gridCounts: counts }
  }, [entries])

  const drillEntries = useMemo(() => {
    if (!drillDown || !entries) return []
    return entries.filter((e) => e.week_of_month === drillDown.week && e.day === drillDown.day)
  }, [drillDown, entries])

  return (
    <div>
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6 mb-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-9 h-9 rounded-full bg-indigo-accent/10 flex items-center justify-center shrink-0">
            <Map size={16} className="text-indigo-accent" />
          </div>
          <div>
            <h2 className="font-bold text-navy-text">Generate Standard Tour Plan</h2>
            <p className="text-xs text-muted-text">
              Upload history + doctor master CSVs. Default MR: {defaultMr ?? '—'}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-wrap items-end gap-3">
          <div>
            <label className="text-xs text-muted-text block mb-1">History CSV</label>
            <input
              ref={historyInputRef}
              type="file"
              accept=".csv"
              onChange={(e) => setHistoryFile(e.target.files?.[0] || null)}
              required
              className="text-sm border border-gray-200 rounded-md px-3 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
            />
          </div>
          <div>
            <label className="text-xs text-muted-text block mb-1">Doctor Master (Synthetic) CSV</label>
            <input
              ref={syntheticInputRef}
              type="file"
              accept=".csv"
              onChange={(e) => setSyntheticFile(e.target.files?.[0] || null)}
              required
              className="text-sm border border-gray-200 rounded-md px-3 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
            />
          </div>
          <button
            type="submit"
            disabled={!historyFile || !syntheticFile || generateMutation.isPending}
            className="flex items-center gap-1.5 text-sm font-semibold px-4 py-2 rounded-full bg-navy-dark text-white hover:opacity-90 transition disabled:opacity-50"
          >
            <Upload size={14} />
            {generateMutation.isPending ? 'Uploading…' : 'Generate Plan'}
          </button>
        </form>

        {uploadError && (
          <div className="flex items-center gap-2 rounded-md bg-red-50 border border-red-100 px-3 py-2 mt-3">
            <AlertCircle size={14} className="text-red-600 shrink-0" />
            <p className="text-sm text-red-700">{uploadError}</p>
          </div>
        )}
      </div>

      {runStatus && <RunStatusBanner run={runStatus} />}

      {runStatus?.status === 'completed' && entries && entries.length > 0 && (
        <>
          <div className="flex justify-end mb-2">
            <a
              href={downloadTourPlanUrl(runId)}
              download
              className="flex items-center gap-1.5 text-sm font-semibold px-4 py-2 rounded-full bg-white border border-gray-300 text-navy-text hover:bg-gray-50 transition"
            >
              <Download size={14} />
              Download Plan
            </a>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden mb-5">
            <div className="px-4 py-3 border-b border-gray-100">
              <h3 className="text-xs font-semibold uppercase tracking-wide text-indigo-accent">
                Weekly Plan — MR {entries[0]?.mr_id ?? ''} (click a cell to see doctors)
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-gray-100 text-left text-xs font-semibold uppercase tracking-wide text-muted-text">
                    <th className="px-3 py-2.5">Week of Month</th>
                  {days.map((d) => (
                    <th key={d} className="px-3 py-2.5 text-center">
                      {d}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {weeks.map((w, i) => (
                  <tr key={w} className={`border-b border-gray-50 ${i % 2 === 1 ? 'bg-gray-50/40' : ''}`}>
                    <td className="px-3 py-2 font-medium text-navy-text">Week {w}</td>
                    {days.map((d) => {
                      const count = gridCounts[`${w}|${d}`] || 0
                      const isActive = drillDown?.week === w && drillDown?.day === d
                      return (
                        <td key={d} className="px-3 py-2 text-center">
                          <button
                            onClick={() => (count > 0 ? setDrillDown({ week: w, day: d }) : null)}
                            disabled={count === 0}
                            className={`w-8 h-8 rounded-md text-xs font-semibold transition ${
                              count === 0
                                ? 'text-gray-300 cursor-default'
                                : isActive
                                ? 'bg-navy-dark text-white'
                                : 'bg-indigo-accent/10 text-indigo-accent hover:bg-indigo-accent/20'
                            }`}
                          >
                            {count}
                          </button>
                        </td>
                      )
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          </div>
        </>
      )}

      {drillDown && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-indigo-accent flex items-center gap-1.5">
              <Users size={13} />
              Week {drillDown.week} · {drillDown.day} — {drillEntries.length} doctor
              {drillEntries.length !== 1 ? 's' : ''}
            </h3>
            <button onClick={() => setDrillDown(null)} className="text-muted-text hover:text-navy-text transition">
              <X size={16} />
            </button>
          </div>
          <div className="divide-y divide-gray-50">
            {drillEntries.map((e, i) => (
              <div key={i} className="px-4 py-2.5 flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm font-medium text-navy-text">{e.party_name || e.doctor_id}</p>
                  <p className="text-xs text-muted-text">
                    {e.specialty || '—'} {e.region ? `· ${e.region}` : ''}
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {e.category && (
                    <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-indigo-accent/10 text-indigo-accent">
                      Cat {e.category}
                    </span>
                  )}
                  {e.potential && (
                    <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-teal-accent/10 text-teal-accent">
                      {e.potential}
                    </span>
                  )}
                  <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-gray-100 text-muted-text">
                    {e.timeslot}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {runStatus?.status === 'completed' && (!entries || entries.length === 0) && (
        <p className="text-sm text-muted-text text-center py-8">
          Plan generated, but no rows for this MR — check the uploaded CSVs.
        </p>
      )}

      {!runStatus && (
        <p className="text-sm text-muted-text text-center py-8">
          No tour plan generated yet. Upload the two CSVs above to get started.
        </p>
      )}
    </div>
  )
}

function RunStatusBanner({ run }) {
  if (run.status === 'generating') {
    return (
      <div className="flex items-center gap-2.5 rounded-md bg-indigo-accent/5 border border-indigo-accent/20 px-4 py-3 mb-5">
        <Loader2 size={16} className="text-indigo-accent animate-spin shrink-0" />
        <p className="text-sm text-indigo-accent font-medium">{run.progress_message || 'Generating…'}</p>
      </div>
    )
  }
  if (run.status === 'error') {
    return (
      <div className="rounded-md bg-red-50 border border-red-100 px-4 py-3 mb-5">
        <div className="flex items-center gap-2">
          <AlertCircle size={16} className="text-red-600 shrink-0" />
          <p className="text-sm font-medium text-red-700">Generation failed</p>
        </div>
        {run.error_message && (
          <textarea
            readOnly
            value={run.error_message}
            className="w-full mt-2 text-xs text-red-700 bg-white border border-red-100 rounded-md px-2.5 py-1.5 resize-none"
            rows={2}
          />
        )}
      </div>
    )
  }
  if (run.status === 'completed') {
    return (
      <div className="flex items-center gap-2 rounded-md bg-teal-accent/5 border border-teal-accent/20 px-4 py-2.5 mb-5">
        <CheckCircle2 size={15} className="text-teal-accent shrink-0" />
        <p className="text-sm text-teal-accent font-medium">Plan generated successfully</p>
      </div>
    )
  }
  return null
}