import { GraduationCap } from 'lucide-react'

export default function LearnPage() {
  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-10 text-center">
      <GraduationCap size={28} className="mx-auto text-muted-text mb-3" />
      <p className="text-sm text-muted-text">Learn is coming soon.</p>
    </div>
  )
}