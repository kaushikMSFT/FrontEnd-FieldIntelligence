import { List, GraduationCap, Megaphone, BarChart3, Settings as SettingsIcon, Stethoscope, FileUp, Map } from 'lucide-react'

const NAV_ITEMS = [
  { key: 'doctor_list', label: 'Doctor List', Icon: List },
  { key: 'learn', label: 'Learn', Icon: GraduationCap },
  { key: 'next_best_action', label: 'Objection Intelligence', Icon: Megaphone },
  { key: 'tour_plan', label: 'Standard Tour Plan', Icon: Map },
  { key: 'sales_iq', label: 'Sales IQ', Icon: BarChart3 },
  { key: 'product_info', label: 'Product Info', Icon: FileUp },
  { key: 'settings', label: 'Settings', Icon: SettingsIcon },
]

export default function Sidebar({ activeSection, onSelectSection, visibleSections }) {
  const items = visibleSections
    ? NAV_ITEMS.filter((item) => visibleSections.includes(item.key))
    : NAV_ITEMS

  return (
    <aside className="w-56 bg-navy-dark text-white flex flex-col shrink-0">
      <div className="px-5 py-6 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Stethoscope size={22} />
          <span className="font-bold text-lg">Field Intelligence</span>
        </div>
      </div>
      <nav className="flex-1 px-3 py-4 space-y-1">
        {items.map(({ key, label, Icon }) => {
          const isActive = activeSection === key
          return (
            <button
              key={key}
              onClick={() => onSelectSection(key)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition text-left ${
                isActive ? 'bg-white/10 text-white' : 'text-white/70 hover:bg-white/5 hover:text-white'
              }`}
            >
              <Icon size={18} className="shrink-0" />
              {label}
            </button>
          )
        })}
      </nav>
    </aside>
  )
}