import {
  Stethoscope,
  ArrowRight,
  Megaphone,
  Map,
  MessageSquare,
  FileText,
  Users,
  Activity,
} from 'lucide-react'

// Each app lists the persona(s) it belongs to. 'Sales Chatbot' appears under
// both MR and FLM, so it carries both tags rather than being duplicated.
const APPS = [
  {
    Icon: Map,
    title: 'Tour Planner',
    description: 'ML-driven weekly scheduling, generated from historical visit patterns and business rules.',
    personas: ['MR'],
  },
  {
    Icon: FileText,
    title: 'Medical Extraction',
    description: 'Pulls structured clinical and product detail out of unstructured documents for quick reference.',
    personas: ['MR'],
  },
  {
    Icon: MessageSquare,
    title: 'Sales Chatbot',
    description: 'Natural-language sales analytics — ask a question, get an answer, a chart, and the real data behind it.',
    personas: ['MR', 'FLM'],
  },
  {
    Icon: Megaphone,
    title: 'Objection Intelligence',
    description:
      'AI-generated visit nudges — context, suggestions, and grounded content, built from real DCR, e-detailing, and engagement history.',
    personas: ['MR'],
    highlighted: true,
  },
  {
    Icon: Users,
    title: 'MR360',
    description: 'A full 360° view of each MR — activity, coverage, and engagement quality in one place.',
    personas: ['FLM'],
  },
  {
    Icon: Activity,
    title: 'Territory Health Monitoring',
    description: 'Tracks territory-level coverage, engagement trends, and risk signals for proactive management.',
    personas: ['FLM'],
  },
]

const PERSONA_TAG_STYLES = {
  MR: 'bg-indigo-accent/10 text-indigo-accent',
  FLM: 'bg-teal-accent/10 text-teal-accent',
}

function AppCard({ Icon, title, description, personas, highlighted }) {
  return (
    <div
      className={`bg-white rounded-lg p-6 border shadow-sm ${
        highlighted ? 'border-indigo-accent/40' : 'border-gray-200'
      }`}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="w-10 h-10 rounded-full bg-indigo-accent/10 flex items-center justify-center">
          <Icon size={18} className="text-indigo-accent" />
        </div>
        <div className="flex gap-1.5">
          {personas.map((p) => (
            <span
              key={p}
              className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${PERSONA_TAG_STYLES[p]}`}
            >
              {p}
            </span>
          ))}
        </div>
      </div>
      <h3 className="font-bold text-navy-text mb-1.5">{title}</h3>
      <p className="text-sm text-muted-text leading-relaxed">{description}</p>
    </div>
  )
}

function PersonaSection({ label, personaKey }) {
  const apps = APPS.filter((a) => a.personas.includes(personaKey))
  return (
    <div className="mb-14">
      <div className="flex items-center gap-2 mb-5">
        <span
          className={`text-xs font-semibold px-2.5 py-1 rounded-full ${PERSONA_TAG_STYLES[personaKey]}`}
        >
          {personaKey}
        </span>
        <h2 className="text-xl font-bold text-navy-text">{label}</h2>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {apps.map((app) => (
          <AppCard key={app.title} {...app} />
        ))}
      </div>
    </div>
  )
}

export default function LandingPage({ onGetStarted }) {
  return (
    <div className="min-h-screen bg-page-bg flex flex-col">
      <header className="flex items-center justify-between px-8 py-5 border-b border-gray-200 bg-white">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-navy-dark flex items-center justify-center shrink-0">
            <Stethoscope size={16} className="text-white" />
          </div>
          <span className="font-bold text-lg text-navy-text">Field Intelligence</span>
          <span className="text-xs font-medium px-2.5 py-1 rounded-full border border-gray-200 text-muted-text">
            Internal Demo
          </span>
        </div>
        <button
          onClick={onGetStarted}
          className="text-sm font-semibold px-5 py-2 rounded-full bg-navy-dark text-white hover:opacity-90 transition"
        >
          Log in
        </button>
      </header>

      <main className="max-w-5xl mx-auto px-6 pt-16 pb-20 text-center">
        <span className="inline-flex items-center gap-1.5 text-sm font-medium px-4 py-1.5 rounded-full bg-indigo-accent/10 text-indigo-accent mb-8">
          <span className="w-1.5 h-1.5 rounded-full bg-indigo-accent" />
          Powered by Nagarro
        </span>
        <h1 className="text-5xl md:text-6xl font-bold leading-tight text-navy-text mb-3">
          AI Assistant
          <br />
          <span className="text-indigo-accent">for Field Force</span>
        </h1>

        <p className="text-lg text-muted-text max-w-2xl mx-auto mt-6 mb-10 leading-relaxed">
          One intelligent platform unifying visit preparation, recommendations, product information, sales assistance, MR 360, and territory health monitoring—turning enterprise data into everyday field decisions.
        </p>

        <button
          onClick={onGetStarted}
          className="inline-flex items-center gap-2 text-sm font-semibold px-6 py-3 rounded-full bg-navy-dark text-white hover:opacity-90 transition"
        >
          Get Started
          <ArrowRight size={16} />
        </button>
      </main>

      <section className="max-w-5xl mx-auto px-6 pb-20 w-full">
        <h2 className="text-2xl font-bold text-navy-text text-center mb-2">Built for how each role works</h2>
        <p className="text-sm text-muted-text text-center mb-10">
          Applications grouped by persona — Sales Chatbot is shared across both.
        </p>

        <PersonaSection label="Medical Representative" personaKey="MR" />
        <PersonaSection label="First Line Manager" personaKey="FLM" />
      </section>

      <footer className="mt-auto border-t border-gray-200 bg-white">
        <div className="max-w-5xl mx-auto px-6 py-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-navy-dark flex items-center justify-center shrink-0">
              <Stethoscope size={11} className="text-white" />
            </div>
            <span className="text-sm font-semibold text-navy-text">Field Intelligence</span>
          </div>
          <p className="text-xs text-muted-text">
            © 2026 Field Intelligence — internal demo, not for external distribution
          </p>
        </div>
      </footer>
    </div>
  )
}