import { LogOut } from 'lucide-react'
import { useAuthStore } from '../store/authStore'
import { logout as apiLogout } from '../api/client'

const SECTION_TITLES = {
  doctor_list: 'Doctor List',
  learn: 'Learn',
  next_best_action: 'Objection Intelligence',
  tour_plan: 'Standard Tour Plan',
  sales_iq: 'Sales IQ',
  product_info: 'Product Info',
  settings: 'Settings',
}

export default function Header({ activeSection }) {
  const { role, username, sessionToken, clearSession } = useAuthStore()

  async function handleLogout() {
    try {
      await apiLogout(sessionToken)
    } finally {
      clearSession()
    }
  }

  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 shrink-0">
      <h2 className="font-semibold text-navy-text">{SECTION_TITLES[activeSection] || 'Visit Prep'}</h2>
      <div className="flex items-center gap-4">
        {username && <span className="text-sm text-muted-text">{username}</span>}
        <span className="text-xs font-medium uppercase tracking-wide px-2.5 py-1 rounded-full bg-indigo-accent/10 text-indigo-accent">
          {role === 'admin' ? 'Super Admin' : 'Medical Rep'}
        </span>
        <button
          onClick={handleLogout}
          className="flex items-center gap-1.5 text-sm text-muted-text hover:text-navy-text transition"
        >
          <LogOut size={16} />
          Sign out
        </button>
      </div>
    </header>
  )
}