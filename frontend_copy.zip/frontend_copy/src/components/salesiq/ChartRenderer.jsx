import LineChart from './charts/LineChart'
import BarChart from './charts/BarChart'
import DualAxisChart from './charts/DualAxisChart'
import HeatmapChart from './charts/HeatmapChart'
import ForecastChart from './charts/ForecastChart'
import DrillDownChart from './charts/DrillDownChart'

export default function ChartRenderer({ chart }) {
  if (!chart) {
    return <div className="p-6 text-center text-muted-text text-sm">No chart data</div>
  }
  const type = (chart.type || 'bar').toString().toLowerCase()
  const common = { chart }

  if (type === 'line') return <LineChart {...common} />
  if (type === 'bar') return <BarChart {...common} />
  if (type === 'dualaxis') return <DualAxisChart {...common} />
  if (type === 'heatmap') return <HeatmapChart {...common} />
  if (type === 'forecast') return <ForecastChart {...common} />
  if (type === 'drilldown') return <DrillDownChart {...common} />

  return <BarChart {...common} />
}
