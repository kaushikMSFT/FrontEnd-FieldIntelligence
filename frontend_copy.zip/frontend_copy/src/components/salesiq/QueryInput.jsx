import { useState } from 'react'
import { Send, Loader2 } from 'lucide-react'

export default function QueryInput({ onAsk, loading }) {
  const [query, setQuery] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    if (query.trim()) onAsk(query.trim())
  }

  return (
    <form onSubmit={handleSubmit} className="mb-4">
      <div className="flex items-start gap-3 flex-wrap">
        <textarea
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ask in natural language, e.g. Top 10 brands by sales, Sales by month, Compare GT vs MT..."
          rows={2}
          disabled={loading}
          className="flex-1 min-w-[280px] text-sm border border-gray-200 rounded-md px-3.5 py-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-accent/30 resize-y disabled:opacity-60"
        />
        <button
          type="submit"
          disabled={loading || !query.trim()}
          className="flex items-center gap-1.5 text-sm font-semibold px-4 py-2.5 rounded-full bg-navy-dark text-white hover:opacity-90 transition disabled:opacity-50 shrink-0"
        >
          {loading ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}
          {loading ? 'Asking…' : 'Ask'}
        </button>
      </div>
    </form>
  )
}
