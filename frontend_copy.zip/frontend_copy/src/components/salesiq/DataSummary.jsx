import { Table2 } from 'lucide-react'
import { formatCellValue } from '../../utils/salesIqFormat'

export default function DataSummary({ data_summary, format = 'paragraph' }) {
  if (!data_summary || data_summary.row_count === 0) return null
  const { row_count, columns, preview } = data_summary
  const isTableFormat = format === 'table'
  const maxCols = isTableFormat ? 12 : 8
  const maxRows = isTableFormat ? 15 : 5

  return (
    <section className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 mb-4">
      <div className="flex items-center gap-1.5 mb-2">
        <Table2 size={13} className="text-indigo-accent" />
        <h3 className="text-xs font-semibold uppercase tracking-wide text-indigo-accent">
          Data Summary — {row_count} row{row_count !== 1 ? 's' : ''}
        </h3>
      </div>
      {preview?.length > 0 && (
        <div className="overflow-x-auto">
          <table className={`w-full ${isTableFormat ? 'text-xs' : 'text-xs'} border-collapse`}>
            <thead>
              <tr>
                {columns?.slice(0, maxCols).map((c) => (
                  <th key={c} className="text-left px-2 py-1.5 border-b border-gray-100 text-muted-text font-semibold uppercase tracking-wide">
                    {c}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {preview.slice(0, maxRows).map((row, i) => (
                <tr key={i} className={i % 2 === 1 ? 'bg-gray-50/40' : ''}>
                  {columns?.slice(0, maxCols).map((col) => (
                    <td key={col} className="px-2 py-1.5 border-b border-gray-50 text-navy-text">
                      {formatCellValue(row[col], col)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  )
}
