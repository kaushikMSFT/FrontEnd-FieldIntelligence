export default function ConfidenceBadge({ confidence }) {
  if (confidence == null) return null
  const pct = Math.round(confidence * 100)
  const color = pct >= 80 ? 'teal' : pct >= 50 ? 'amber' : 'red'
  const styles = {
    teal: { bg: 'bg-teal-accent/10', text: 'text-teal-accent', bar: '#0FB59A' },
    amber: { bg: 'bg-amber-50', text: 'text-amber-600', bar: '#D97706' },
    red: { bg: 'bg-red-50', text: 'text-red-600', bar: '#DC2626' },
  }[color]

  return (
    <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${styles.bg} ${styles.text}`}>
      <span className="w-14 h-1.5 bg-white/60 rounded-full overflow-hidden">
        <span className="block h-full rounded-full" style={{ width: `${pct}%`, background: styles.bar }} />
      </span>
      Confidence {pct}%
    </div>
  )
}
