import { Lightbulb } from 'lucide-react'

/** Split text into bullet items: by newlines first, then by sentence. */
function toBulletItems(text) {
  if (!text || typeof text !== 'string') return []
  const byNewline = text.trim().split(/\n+/).filter(Boolean)
  if (byNewline.length > 1) return byNewline.map((s) => s.trim())
  return text
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter(Boolean)
}

export default function InsightPanel({ insight, format = 'paragraph' }) {
  if (!insight) return null
  const isBullets = format === 'bullets'
  const items = isBullets ? toBulletItems(insight) : null

  return (
    <section className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 mb-4">
      <div className="flex items-center gap-1.5 mb-2">
        <Lightbulb size={13} className="text-indigo-accent" />
        <h3 className="text-xs font-semibold uppercase tracking-wide text-indigo-accent">Insight</h3>
      </div>
      {isBullets && items?.length > 0 ? (
        <ul className="m-0 pl-5 text-sm text-navy-text whitespace-pre-wrap list-disc space-y-1">
          {items.map((item, i) => (
            <li key={i}>{item}</li>
          ))}
        </ul>
      ) : (
        <p className="m-0 text-sm text-navy-text whitespace-pre-wrap">{insight}</p>
      )}
    </section>
  )
}
