import { useState, useMemo } from 'react'
import { BarChart as RechartsBar, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

export default function DrillDownChart({ chart }) {
  const { data = [], drillDownLevels = [], xAxis = {}, yAxis = [], title } = chart || {}
  const levels = drillDownLevels?.length ? drillDownLevels : data[0] ? Object.keys(data[0]).filter((k) => typeof data[0][k] !== 'number') : []
  const [levelIndex, setLevelIndex] = useState(0)
  const [stack, setStack] = useState([])

  const xKey = levels[levelIndex] || xAxis?.field || (data[0] && Object.keys(data[0])[0])
  const yKey = yAxis[0]?.field || (data[0] && Object.keys(data[0]).find((k) => typeof data[0][k] === 'number'))

  const filteredData = useMemo(() => {
    if (stack.length === 0) return data
    let out = data
    stack.forEach(({ level, value }) => {
      const col = levels[level]
      if (col) out = out.filter((d) => String(d[col]) === String(value))
    })
    return out
  }, [data, stack, levels])

  const aggregated = useMemo(() => {
    if (!filteredData.length || !xKey || !yKey) return []
    const map = {}
    filteredData.forEach((d) => {
      const k = String(d[xKey] ?? '')
      map[k] = (map[k] || 0) + (Number(d[yKey]) || 0)
    })
    return Object.entries(map).map(([name, value]) => ({ [xKey]: name, [yKey]: value }))
  }, [filteredData, xKey, yKey])

  const handleBarClick = (e) => {
    if (!e?.activePayload?.[0]?.payload || levelIndex >= levels.length - 1) return
    const value = e.activePayload[0].payload[xKey]
    setStack((s) => [...s, { level: levelIndex, value }])
    setLevelIndex((i) => Math.min(i + 1, levels.length - 1))
  }

  const handleBack = () => {
    if (stack.length === 0) return
    setStack((s) => s.slice(0, -1))
    setLevelIndex((i) => Math.max(0, i - 1))
  }

  return (
    <div className="w-full" style={{ height: 360 }}>
      {title && <h3 className="mb-2 text-sm font-semibold text-navy-text">{title}</h3>}
      {stack.length > 0 && (
        <button
          type="button"
          onClick={handleBack}
          className="mb-2 px-3 py-1 text-sm rounded-full bg-white border border-gray-300 text-muted-text hover:bg-gray-50 transition"
        >
          ← Back
        </button>
      )}
      <ResponsiveContainer width="100%" height={320}>
        <RechartsBar data={aggregated} margin={{ top: 8, right: 8, left: 8, bottom: 8 }} onClick={handleBarClick}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
          <XAxis dataKey={xKey} stroke="#9CA3AF" fontSize={12} tick={{ fill: '#6B7280' }} />
          <YAxis stroke="#9CA3AF" fontSize={12} tick={{ fill: '#6B7280' }} />
          <Tooltip contentStyle={{ background: '#fff', border: '1px solid #E5E7EB' }} cursor={{ fill: 'rgba(91,75,154,0.08)' }} />
          <Bar dataKey={yKey} fill="#5B4B9A" radius={[4, 4, 0, 0]} />
        </RechartsBar>
      </ResponsiveContainer>
      {levels.length > 1 && (
        <p className="mt-1 text-xs text-muted-text">
          Level: {levels[levelIndex] || xKey}. Click a bar to drill down.
        </p>
      )}
    </div>
  )
}
