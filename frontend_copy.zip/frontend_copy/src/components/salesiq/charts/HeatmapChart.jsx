import { formatCurrencyINR, isAmountColumn } from '../../../utils/salesIqFormat'

export default function HeatmapChart({ chart }) {
  const { data = [], xAxis = {}, yAxis = [], title } = chart || {}
  const xKey = xAxis?.field || (data[0] && Object.keys(data[0])[0])
  const valueKey = yAxis[0]?.field || (data[0] && Object.keys(data[0]).find((k) => k !== xKey && typeof data[0][k] === 'number'))
  if (!data.length || !xKey) return <div className="p-4 text-sm text-muted-text">No heatmap data</div>

  const formatCell = (v) =>
    isAmountColumn(valueKey) ? formatCurrencyINR(v) : typeof v === 'number' ? v.toLocaleString(undefined, { maximumFractionDigits: 2 }) : v

  const rowKey = data[0] && Object.keys(data[0]).find((k) => k !== xKey && k !== valueKey)
  const rows = rowKey ? [...new Set(data.map((d) => String(d[rowKey])))] : [null]
  const cols = [...new Set(data.map((d) => String(d[xKey])))]
  const map = {}
  data.forEach((d) => {
    const r = rowKey ? String(d[rowKey]) : 'value'
    const c = String(d[xKey])
    map[`${r}|${c}`] = Number(d[valueKey]) ?? 0
  })
  const vals = Object.values(map).filter((v) => !Number.isNaN(v))
  const min = Math.min(...vals, 0)
  const max = Math.max(...vals, 1)

  // Light-to-teal-accent gradient, replacing their dark-theme indigo-to-blue gradient
  const color = (v) => {
    const t = max === min ? 0.5 : (v - min) / (max - min)
    const r = Math.round(244 + (15 - 244) * t)
    const g = Math.round(245 + (181 - 245) * t)
    const b = Math.round(249 + (154 - 249) * t)
    return `rgb(${r},${g},${b})`
  }

  return (
    <div className="w-full overflow-auto">
      {title && <h3 className="mb-2 text-sm font-semibold text-navy-text">{title}</h3>}
      <table className="border-collapse text-xs">
        <thead>
          <tr>
            <th className="p-1.5 border border-gray-200 text-muted-text">{rowKey || ''}</th>
            {cols.map((c) => (
              <th key={c} className="p-1.5 border border-gray-200 text-muted-text">
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r ?? 'single'}>
              <td className="p-1.5 border border-gray-200 font-medium text-navy-text">{r ?? ''}</td>
              {cols.map((c) => {
                const v = map[`${r ?? 'value'}|${c}`] ?? 0
                return (
                  <td
                    key={c}
                    className="p-1.5 border border-gray-200"
                    style={{ background: color(v), color: v > (min + max) / 2 ? '#fff' : '#16213E' }}
                  >
                    {formatCell(v)}
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
