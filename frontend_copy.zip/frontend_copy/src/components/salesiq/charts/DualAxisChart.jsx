import { ComposedChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { formatCurrencyINR, isAmountColumn } from '../../../utils/salesIqFormat'

export default function DualAxisChart({ chart }) {
  const { data = [], xAxis = {}, yAxis = [], title } = chart || {}
  const xKey = xAxis?.field || (data[0] && Object.keys(data[0])[0]) || 'x'
  const y1 = yAxis[0]?.field
  const y2 = yAxis[1]?.field
  const keys = data[0] ? Object.keys(data[0]).filter((k) => k !== xKey && typeof data[0][k] === 'number') : []
  const first = y1 || keys[0]
  const second = y2 || keys[1]

  return (
    <div className="w-full h-80">
      {title && <h3 className="mb-2 text-sm font-semibold text-navy-text">{title}</h3>}
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data} margin={{ top: 8, right: 8, left: 8, bottom: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
          <XAxis dataKey={xKey} stroke="#9CA3AF" fontSize={12} tick={{ fill: '#6B7280' }} />
          <YAxis
            yAxisId="left"
            stroke="#9CA3AF"
            fontSize={12}
            tick={{ fill: '#6B7280' }}
            tickFormatter={first && isAmountColumn(first) ? (v) => formatCurrencyINR(v) : undefined}
          />
          <YAxis
            yAxisId="right"
            orientation="right"
            stroke="#9CA3AF"
            fontSize={12}
            tick={{ fill: '#6B7280' }}
            tickFormatter={second && isAmountColumn(second) ? (v) => formatCurrencyINR(v) : undefined}
          />
          <Tooltip
            contentStyle={{ background: '#fff', border: '1px solid #E5E7EB' }}
            formatter={(value) => ((isAmountColumn(first) || isAmountColumn(second)) ? formatCurrencyINR(value) : value)}
          />
          <Legend />
          {first && <Bar yAxisId="left" dataKey={first} fill="#5B4B9A" radius={[4, 4, 0, 0]} name={yAxis[0]?.label || first} />}
          {second && <Line yAxisId="right" type="monotone" dataKey={second} stroke="#0FB59A" strokeWidth={2} name={yAxis[1]?.label || second} />}
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  )
}
