import { LineChart as RechartsLine, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'

export default function ForecastChart({ chart }) {
  const { data = [], forecastSeries = [], xAxis = {}, yAxis = [], title } = chart || {}
  const xKey = xAxis?.field || 'period'
  const yKey = yAxis[0]?.field || (data[0] && Object.keys(data[0]).find((k) => k !== xKey && typeof data[0][k] === 'number')) || 'y'

  const historical = (data || []).map((d) => ({ ...d, forecast: null }))
  const forecast = (forecastSeries || []).map((d) => {
    const val = d[yKey] ?? Object.values(d).find((v) => typeof v === 'number')
    return { [xKey]: d.period ?? d[xKey], [yKey]: null, forecast: val }
  })
  const combined = [...historical, ...forecast]

  return (
    <div className="w-full h-80">
      {title && <h3 className="mb-2 text-sm font-semibold text-navy-text">{title}</h3>}
      <ResponsiveContainer width="100%" height="100%">
        <RechartsLine data={combined} margin={{ top: 8, right: 8, left: 8, bottom: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
          <XAxis dataKey={xKey} stroke="#9CA3AF" fontSize={12} tick={{ fill: '#6B7280' }} />
          <YAxis stroke="#9CA3AF" fontSize={12} tick={{ fill: '#6B7280' }} />
          <Tooltip contentStyle={{ background: '#fff', border: '1px solid #E5E7EB' }} />
          <Legend />
          <Line type="monotone" dataKey={yKey} stroke="#5B4B9A" strokeWidth={2} dot={{ fill: '#5B4B9A' }} name="Historical" connectNulls />
          <Line type="monotone" dataKey="forecast" stroke="#0FB59A" strokeWidth={2} strokeDasharray="5 5" dot={{ fill: '#0FB59A' }} name="Forecast" connectNulls />
        </RechartsLine>
      </ResponsiveContainer>
    </div>
  )
}
