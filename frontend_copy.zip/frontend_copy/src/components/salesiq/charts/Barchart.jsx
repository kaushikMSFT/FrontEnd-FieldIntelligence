import { BarChart as RechartsBar, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { formatCurrencyINR, isAmountColumn } from '../../../utils/salesIqFormat'

export default function BarChart({ chart }) {
  const { data = [], xAxis = {}, yAxis = [], title } = chart || {}
  const hasData = Array.isArray(data) && data.length > 0
  const xKey = xAxis?.field || (data[0] && Object.keys(data[0])[0]) || 'x'
  const yKey =
    yAxis[0]?.field || (data[0] && Object.keys(data[0]).find((k) => k !== xKey && typeof data[0][k] === 'number')) || 'y'

  const formatTooltipValue = (value, key) => (isAmountColumn(key) ? formatCurrencyINR(value) : value)

  if (!hasData) {
    return (
      <div className="w-full min-h-[200px] p-6 flex flex-col items-center justify-center text-muted-text text-sm">
        {title && <h3 className="mb-2 text-sm font-semibold text-navy-text">{title}</h3>}
        <p>No data to display for this query.</p>
      </div>
    )
  }

  return (
    <div className="w-full h-80">
      {title && <h3 className="mb-2 text-sm font-semibold text-navy-text">{title}</h3>}
      <ResponsiveContainer width="100%" height="100%">
        <RechartsBar data={data} margin={{ top: 8, right: 8, left: 8, bottom: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
          <XAxis dataKey={xKey} stroke="#9CA3AF" fontSize={12} tick={{ fill: '#6B7280' }} />
          <YAxis
            stroke="#9CA3AF"
            fontSize={12}
            tick={{ fill: '#6B7280' }}
            tickFormatter={isAmountColumn(yKey) ? (v) => formatCurrencyINR(v) : undefined}
          />
          <Tooltip contentStyle={{ background: '#fff', border: '1px solid #E5E7EB' }} formatter={(value) => formatTooltipValue(value, yKey)} />
          <Bar dataKey={yKey} fill="#5B4B9A" radius={[4, 4, 0, 0]} isAnimationActive={false} />
        </RechartsBar>
      </ResponsiveContainer>
    </div>
  )
}