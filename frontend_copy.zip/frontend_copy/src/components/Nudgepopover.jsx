import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { X, Megaphone, ThumbsUp, ThumbsDown, MessageSquare, CheckCircle2, ChevronDown, FileText, Presentation, Mail, Info, Users } from 'lucide-react'
import { fetchNudge, submitFeedback } from '../api/client'

export default function NudgePopover({ doctor, onClose }) {
  const queryClient = useQueryClient()
  const [feedbackText, setFeedbackText] = useState('')
  const [showFeedbackInput, setShowFeedbackInput] = useState(false)

  const { data: nudge, isLoading, isError, error } = useQuery({
    queryKey: ['nudge', doctor.hcp_id],
    queryFn: () => fetchNudge(doctor.hcp_id, 'on_demand'),
    retry: false,
  })

  const feedbackMutation = useMutation({
    mutationFn: ({ feedbackType, text }) => submitFeedback(doctor.hcp_id, nudge.id, feedbackType, text),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['nudge', doctor.hcp_id] })
      setFeedbackText('')
      setShowFeedbackInput(false)
    },
  })

  return (
    <>
      {/* backdrop — click to close */}
      <div className="fixed inset-0 bg-black/20 z-40" onClick={onClose} />

      <div className="fixed top-20 right-6 z-50 w-[420px] max-h-[80vh] overflow-y-auto bg-white rounded-xl shadow-xl border border-gray-100">
        <div className="flex items-center justify-between px-5 pt-5 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-indigo-accent/10 flex items-center justify-center shrink-0">
              <Megaphone size={16} className="text-indigo-accent" />
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-teal-accent/10 text-teal-accent">
              Nudge
            </span>
          </div>
          <button onClick={onClose} className="text-muted-text hover:text-navy-text transition">
            <X size={18} />
          </button>
        </div>

        {nudge && nudge.status !== 'exception' && (
          <div className="px-5 -mt-1 mb-1 flex justify-end">
            <ScoreTile score={nudge.relevance_score} />
          </div>
        )}

        <div className="px-5 pb-5">
          <p className="text-xs text-muted-text mb-3">{doctor.name} · {doctor.hcp_id}</p>

          {isLoading && <p className="text-sm text-muted-text py-4">Generating nudge…</p>}

          {isError && (
            <div className="rounded-md bg-red-50 border border-red-100 px-3 py-2.5 text-sm text-red-700">
              Couldn't generate a nudge right now. {error.message}
            </div>
          )}

          {nudge?.status === 'exception' && (
            <div className="flex items-start gap-3 rounded-md border-l-4 border-muted-border bg-gray-50 px-4 py-3">
              <Info size={18} className="text-muted-text mt-0.5 shrink-0" />
              <p className="text-sm text-muted-text">{nudge.message}</p>
            </div>
          )}

          {nudge && nudge.status !== 'exception' && (
            <div className="space-y-4">
              {nudge.is_cohort_based && (
                <div className="flex items-center gap-2 rounded-md bg-indigo-accent/5 border border-indigo-accent/20 px-3 py-2">
                  <Users size={14} className="text-indigo-accent shrink-0" />
                  <p className="text-xs text-indigo-accent font-medium">
                    First interaction — this recommendation is based on similar doctors, not {doctor.name}'s own history.
                  </p>
                </div>
              )}

              <div className="flex flex-wrap items-center gap-1.5">
                {nudge.drug_focus && (
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-navy-dark text-white">
                    {nudge.drug_focus}
                  </span>
                )}
                {nudge.themes?.map((theme) => (
                  <span
                    key={theme}
                    className="text-xs font-medium px-2.5 py-1 rounded-full bg-indigo-accent/10 text-indigo-accent"
                  >
                    {formatLabel(theme)}
                  </span>
                ))}
                {nudge.hcp_sentiments?.map((sentiment) => (
                  <span
                    key={sentiment}
                    className={`text-xs font-medium px-2.5 py-1 rounded-full ${sentimentStyle(sentiment)}`}
                  >
                    {formatLabel(sentiment)}
                  </span>
                ))}
              </div>

              <div className="rounded-md bg-gray-50/80 border border-gray-100 px-4 py-3">
                <h3 className="font-bold text-navy-text leading-snug">{nudge.topic_title}</h3>
                <p className="text-sm text-navy-text mt-1.5 leading-relaxed line-clamp-3">{nudge.context_summary}</p>
              </div>

              {nudge.suggestions?.length > 0 && (
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-teal-accent mb-1.5">Suggestion</p>
                  <ul className="space-y-1.5">
                    {nudge.suggestions.map((s, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-navy-text">
                        <span className="w-1.5 h-1.5 rounded-full bg-teal-accent mt-1.5 shrink-0" />
                        <span>{s.description}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {nudge.cited_evidence?.length > 0 && <SourcesSection evidence={nudge.cited_evidence} />}

              <p className="text-xs text-muted-text">
                Generated {new Date(nudge.generated_at).toLocaleString()}
              </p>

              <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-gray-100">
                <button
                  onClick={() => feedbackMutation.mutate({ feedbackType: 'read' })}
                  disabled={feedbackMutation.isPending}
                  className={`flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-full transition ${
                    nudge.is_read
                      ? 'bg-teal-accent/10 text-teal-accent'
                      : 'bg-navy-dark text-white hover:opacity-90'
                  }`}
                >
                  <CheckCircle2 size={15} />
                  {nudge.is_read ? 'Read' : 'Mark as read'}
                </button>

                <button
                  onClick={() => feedbackMutation.mutate({ feedbackType: 'like' })}
                  disabled={feedbackMutation.isPending}
                  className="flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-full border border-gray-200 text-muted-text hover:border-teal-accent hover:text-teal-accent transition"
                >
                  <ThumbsUp size={15} />
                  Like
                </button>

                <button
                  onClick={() => feedbackMutation.mutate({ feedbackType: 'dislike' })}
                  disabled={feedbackMutation.isPending}
                  className="flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-full border border-gray-200 text-muted-text hover:border-red-400 hover:text-red-500 transition"
                >
                  <ThumbsDown size={15} />
                  Dislike
                </button>

                <button
                  onClick={() => setShowFeedbackInput((v) => !v)}
                  className="flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-full border border-gray-200 text-muted-text hover:border-indigo-accent hover:text-indigo-accent transition"
                >
                  <MessageSquare size={15} />
                  Feedback
                </button>
              </div>

              {showFeedbackInput && (
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={feedbackText}
                    onChange={(e) => setFeedbackText(e.target.value)}
                    placeholder="Add a note…"
                    className="flex-1 text-sm border border-gray-200 rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
                  />
                  <button
                    onClick={() => feedbackMutation.mutate({ feedbackType: 'feedback', text: feedbackText })}
                    disabled={feedbackMutation.isPending || !feedbackText.trim()}
                    className="text-sm font-medium px-4 py-2 rounded-full bg-navy-dark text-white disabled:opacity-40"
                  >
                    Send
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  )
}

function formatLabel(value) {
  return value.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
}

function sentimentStyle(sentiment) {
  switch (sentiment) {
    case 'Frustrated':
      return 'bg-red-50 text-red-600'
    case 'Disengaged':
      return 'bg-gray-100 text-muted-text'
    case 'Curious':
      return 'bg-green-50 text-green-600'
    default:
      return 'bg-gray-100 text-muted-text'
  }
}

function sourceMeta(source) {
  switch (source) {
    case 'DCR':
      return { label: 'DCR Note', Icon: FileText }
    case 'EDetailing':
      return { label: 'E-detailing Slide', Icon: Presentation }
    case 'ContentRequest':
      return { label: 'Content Request', Icon: Mail }
    default:
      return { label: source, Icon: FileText }
  }
}

function SourcesSection({ evidence }) {
  const [expanded, setExpanded] = useState(false)

  return (
    <div className="border-t border-gray-100 pt-3">
      <button
        onClick={() => setExpanded((v) => !v)}
        className="flex items-center gap-1.5 text-xs font-medium text-muted-text hover:text-navy-text transition"
      >
        <ChevronDown size={13} className={`transition-transform ${expanded ? 'rotate-180' : ''}`} />
        Sources ({evidence.length})
      </button>

      {expanded && (
        <div className="mt-2 space-y-2">
          {evidence.map((e) => {
            const { label, Icon } = sourceMeta(e.source)
            return (
              <div key={e.interactionId} className="text-xs border border-gray-100 rounded-md px-3 py-2 bg-gray-50/40">
                <div className="flex items-center gap-1.5 text-muted-text mb-1">
                  <Icon size={12} />
                  <span className="font-medium">{label}</span>
                  <span>· {e.date}</span>
                  <span className="text-gray-300">· {e.interactionId}</span>
                </div>
                <p className="text-navy-text leading-relaxed">{e.rawEvidence}</p>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

function ScoreTile({ score }) {
  const strong = score > 0
  return (
    <div
      className={`flex flex-col items-center justify-center rounded-md px-3 py-1.5 min-w-[52px] ${
        strong ? 'bg-teal-accent/10' : 'bg-gray-100'
      }`}
    >
      <span className={`text-lg font-bold leading-tight ${strong ? 'text-teal-accent' : 'text-muted-text'}`}>
        {score}
      </span>
      <span className="text-[10px] text-muted-text uppercase tracking-wide">score</span>
    </div>
  )
}