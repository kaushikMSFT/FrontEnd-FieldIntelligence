import { useEffect, useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Save, Check } from 'lucide-react'
import { fetchAdminConfig, updateAdminConfig } from '../api/client'
import { useAuthStore } from '../store/authStore'

export default function AdminPanel() {
  const sessionToken = useAuthStore((s) => s.sessionToken)
  const queryClient = useQueryClient()
  const [form, setForm] = useState(null)
  const [saved, setSaved] = useState(false)

  const { data, isLoading, isError } = useQuery({
    queryKey: ['adminConfig'],
    queryFn: () => fetchAdminConfig(sessionToken),
  })

  useEffect(() => {
    if (data) setForm(data)
  }, [data])

  const saveMutation = useMutation({
    mutationFn: (config) => updateAdminConfig(sessionToken, config),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminConfig'] })
      setSaved(true)
      setTimeout(() => setSaved(false), 2000)
    },
  })

  if (isLoading || !form) return <p className="text-sm text-muted-text">Loading configuration…</p>
  if (isError) return <p className="text-sm text-red-600">Couldn't load admin config. Is the backend running?</p>

  const update = (key, value) => setForm((f) => ({ ...f, [key]: value }))

  return (
    <div className="max-w-2xl bg-white rounded-lg border border-gray-200 shadow-sm p-6 space-y-6">
      <div>
        <h2 className="text-lg font-bold text-navy-text">AI Nudge Configuration</h2>
        <p className="text-sm text-muted-text mt-1">
          Changes apply to future nudge generations. Scheduled-nudge timing settings aren't shown here yet — that
          feature isn't built in this build.
        </p>
      </div>

      <Section title="Eligibility">
        <Field
          label="E-detailing time threshold (seconds)"
          hint="A doctor needs at least this much total e-detailing engagement to be classified AI Ready."
          value={form.eligibility_threshold_seconds}
          onChange={(v) => update('eligibility_threshold_seconds', v)}
        />
      </Section>

      <Section title="Ranking">
        <Field
          label="Half-life (days)"
          hint="How quickly older signals lose ranking weight. Lower = recency matters more."
          value={form.ranking_half_life_days}
          onChange={(v) => update('ranking_half_life_days', v)}
        />
        <Field
          label="Top N signals sent to the model"
          hint="How many ranked signals are included as context per nudge generation."
          value={form.ranking_top_n}
          onChange={(v) => update('ranking_top_n', v)}
        />
      </Section>

      <Section title="Relevance Score Weights">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Read" value={form.relevance_weight_read} onChange={(v) => update('relevance_weight_read', v)} />
          <Field label="Like" value={form.relevance_weight_like} onChange={(v) => update('relevance_weight_like', v)} />
          <Field
            label="Dislike"
            value={form.relevance_weight_dislike}
            onChange={(v) => update('relevance_weight_dislike', v)}
          />
          <Field
            label="Feedback"
            value={form.relevance_weight_feedback}
            onChange={(v) => update('relevance_weight_feedback', v)}
          />
        </div>
        <Field
          label="Cache bypass threshold"
          hint="A cached nudge scoring below this is regenerated instead of re-served (e.g. after a dislike)."
          value={form.relevance_cache_bypass_below_score}
          onChange={(v) => update('relevance_cache_bypass_below_score', v)}
        />
      </Section>

      <Section title="Signal Extraction (DCR Notes & Content Requests)">
        <div>
          <label className="text-sm font-medium text-navy-text block mb-1">Extraction mode</label>
          <select
            value={form.extraction_mode}
            onChange={(e) => update('extraction_mode', e.target.value)}
            className="w-full text-sm border border-gray-200 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
          >
            <option value="llm">LLM (recommended — accurate on real narrative text)</option>
            <option value="keyword">Keyword (free, but unreliable on this data — see docs)</option>
          </select>
        </div>
        <Field
          label="Action item engagement boost"
          hint="Extra ranking weight given to notes flagged with a follow-up action item (LLM mode only)."
          value={form.action_item_engagement_boost}
          onChange={(v) => update('action_item_engagement_boost', v)}
          step="0.5"
        />
      </Section>

      <Section title="E-detailing Engagement Thresholds">
        <Field
          label="Low engagement max (seconds)"
          value={form.engagement_low_max_seconds}
          onChange={(v) => update('engagement_low_max_seconds', v)}
        />
        <Field
          label="Medium engagement max (seconds)"
          hint="Above this is High engagement."
          value={form.engagement_medium_max_seconds}
          onChange={(v) => update('engagement_medium_max_seconds', v)}
        />
      </Section>

      <div className="flex items-center gap-3 pt-2 border-t border-gray-100">
        <button
          onClick={() => saveMutation.mutate(form)}
          disabled={saveMutation.isPending}
          className="flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-full bg-navy-dark text-white hover:opacity-90 transition disabled:opacity-50"
        >
          <Save size={14} />
          {saveMutation.isPending ? 'Saving…' : 'Save changes'}
        </button>
        {saved && (
          <span className="flex items-center gap-1 text-sm text-teal-accent">
            <Check size={14} /> Saved
          </span>
        )}
        {saveMutation.isError && <span className="text-sm text-red-600">Save failed — check you're signed in as Admin.</span>}
      </div>
    </div>
  )
}

function Section({ title, children }) {
  return (
    <div className="space-y-3">
      <h3 className="text-xs font-semibold uppercase tracking-wide text-indigo-accent">{title}</h3>
      {children}
    </div>
  )
}

function Field({ label, hint, value, onChange, step = '1' }) {
  return (
    <div>
      <label className="text-sm font-medium text-navy-text block mb-1">{label}</label>
      <input
        type="number"
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full text-sm border border-gray-200 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
      />
      {hint && <p className="text-xs text-muted-text mt-1">{hint}</p>}
    </div>
  )
}