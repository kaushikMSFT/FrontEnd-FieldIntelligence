import { Mail, Calendar, Clock, Hash } from 'lucide-react'
import StatusBadge from './StatusBadge'

export default function DoctorInfoPanel({ doctor }) {
  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
      <div className="flex items-start justify-between mb-5">
        <div>
          <h3 className="text-lg font-bold text-navy-text">{doctor.name}</h3>
          <p className="text-sm text-muted-text">{doctor.hcp_id}</p>
        </div>
        <StatusBadge status={doctor.status} />
      </div>

      <dl className="space-y-3 text-sm">
        <div className="flex items-center gap-2.5 text-navy-text">
          <Hash size={15} className="text-muted-text shrink-0" />
          <span className="text-muted-text w-28 shrink-0">Priority</span>
          <span className="font-medium">{doctor.priority}</span>
        </div>

        {doctor.email_address && (
          <div className="flex items-center gap-2.5 text-navy-text">
            <Mail size={15} className="text-muted-text shrink-0" />
            <span className="text-muted-text w-28 shrink-0">Email</span>
            <span className="font-medium">{doctor.email_address}</span>
          </div>
        )}

        {doctor.next_visit_date && (
          <div className="flex items-center gap-2.5 text-navy-text">
            <Calendar size={15} className="text-muted-text shrink-0" />
            <span className="text-muted-text w-28 shrink-0">Next visit</span>
            <span className="font-medium">{doctor.next_visit_date}</span>
          </div>
        )}

        {doctor.next_visit_timeslot && (
          <div className="flex items-center gap-2.5 text-navy-text">
            <Clock size={15} className="text-muted-text shrink-0" />
            <span className="text-muted-text w-28 shrink-0">Timeslot</span>
            <span className="font-medium">{doctor.next_visit_timeslot}</span>
          </div>
        )}
      </dl>

      {doctor.status === 'ai_ready' ? (
        <p className="text-xs text-muted-text mt-5 pt-4 border-t border-gray-100">
          Click the bell icon next to this doctor's name to view their visit prep nudge.
        </p>
      ) : (
        <p className="text-xs text-muted-text mt-5 pt-4 border-t border-gray-100">
          Not enough interaction data yet — nudges unavailable for this doctor.
        </p>
      )}
    </div>
  )
}