import { List } from 'lucide-react'

export default function DoctorListPage() {
  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-10 text-center">
      <List size={28} className="mx-auto text-muted-text mb-3" />
      <p className="text-sm text-muted-text">Doctor List is coming soon.</p>
    </div>
  )
}