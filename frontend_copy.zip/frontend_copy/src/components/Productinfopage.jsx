import { useRef, useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { FileUp, Upload, PlayCircle, AlertCircle, CheckCircle2, Clock, Loader2 } from 'lucide-react'
import { fetchAvailableDrugs, fetchPIDocuments, uploadPIDocument, submitForIngestion } from '../api/client'
import ProductChatPanel from './ProductChatPanel'

export default function ProductInfoPage() {
  const queryClient = useQueryClient()
  const fileInputRef = useRef(null)
  const [selectedDrug, setSelectedDrug] = useState('')
  const [selectedFile, setSelectedFile] = useState(null)
  const [uploadError, setUploadError] = useState(null)

  const { data: drugs } = useQuery({ queryKey: ['availableDrugs'], queryFn: fetchAvailableDrugs })
  const { data: documents, isLoading } = useQuery({
    queryKey: ['piDocuments'],
    queryFn: fetchPIDocuments,
    refetchInterval: 3000, // poll — ingestion runs as a background task, this is how status updates reach the UI
  })

  const uploadMutation = useMutation({
    mutationFn: () => uploadPIDocument(selectedDrug, selectedFile),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['piDocuments'] })
      setSelectedFile(null)
      setSelectedDrug('')
      setUploadError(null)
      if (fileInputRef.current) fileInputRef.current.value = ''
    },
    onError: (e) => setUploadError(e.message),
  })

  const ingestMutation = useMutation({
    mutationFn: (docId) => submitForIngestion(docId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['piDocuments'] }),
  })

  function handleUpload(e) {
    e.preventDefault()
    setUploadError(null)
    uploadMutation.mutate()
  }

  return (
    <div className="flex gap-5 items-start">
      <div className="w-[420px] shrink-0 min-w-0">
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6 mb-5">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-9 h-9 rounded-full bg-indigo-accent/10 flex items-center justify-center shrink-0">
              <FileUp size={16} className="text-indigo-accent" />
            </div>
            <div>
              <h2 className="font-bold text-navy-text">Upload Product Information</h2>
              <p className="text-xs text-muted-text">PDF, DOCX, or TXT — one drug per upload.</p>
            </div>
          </div>

          <form onSubmit={handleUpload} className="flex flex-wrap items-end gap-3">
            <div>
              <label className="text-xs text-muted-text block mb-1">Drug</label>
              <select
                value={selectedDrug}
                onChange={(e) => setSelectedDrug(e.target.value)}
                required
                className="text-sm border border-gray-200 rounded-full px-3.5 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-accent/30 min-w-[160px]"
              >
                <option value="" disabled>
                  Select a drug…
                </option>
                {(drugs || []).map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs text-muted-text block mb-1">File</label>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.docx,.txt"
                onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                required
                className="text-sm border border-gray-200 rounded-md px-3 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
              />
            </div>

            <button
              type="submit"
              disabled={!selectedDrug || !selectedFile || uploadMutation.isPending}
              className="flex items-center gap-1.5 text-sm font-semibold px-4 py-2 rounded-full bg-navy-dark text-white hover:opacity-90 transition disabled:opacity-50"
            >
              <Upload size={14} />
              {uploadMutation.isPending ? 'Uploading…' : 'Upload'}
            </button>
          </form>

          {uploadError && (
            <div className="flex items-center gap-2 rounded-md bg-red-50 border border-red-100 px-3 py-2 mt-3">
              <AlertCircle size={14} className="text-red-600 shrink-0" />
              <p className="text-sm text-red-700">{uploadError}</p>
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-indigo-accent">Uploaded Documents</h3>
          </div>

          {isLoading && <p className="text-sm text-muted-text p-4">Loading…</p>}

          {!isLoading && (!documents || documents.length === 0) && (
            <p className="text-sm text-muted-text p-6 text-center">No documents uploaded yet.</p>
          )}

          {!isLoading && documents && documents.length > 0 && (
            <div className="divide-y divide-gray-50">
              {documents.map((doc) => (
                <DocumentRow key={doc.id} doc={doc} onIngest={() => ingestMutation.mutate(doc.id)} />
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 min-w-0 sticky top-6" style={{ height: 'calc(100vh - 140px)' }}>
        <ProductChatPanel />
      </div>
    </div>
  )
}

function DocumentRow({ doc, onIngest }) {
  return (
    <div className="px-4 py-3 flex items-center justify-between gap-4">
      <div className="min-w-0">
        <p className="text-sm font-medium text-navy-text truncate">{doc.original_filename}</p>
        <p className="text-xs text-muted-text">
          {doc.drug_name} · uploaded {new Date(doc.uploaded_at).toLocaleString()}
        </p>
        {doc.status === 'error' && doc.error_message && (
          <textarea
            readOnly
            value={doc.error_message}
            className="w-full mt-2 text-xs text-red-700 bg-red-50 border border-red-100 rounded-md px-2.5 py-1.5 resize-none"
            rows={2}
          />
        )}
      </div>

      <div className="flex items-center gap-3 shrink-0">
        <StatusPill status={doc.status} />
        {doc.status === 'uploaded' && (
          <button
            onClick={onIngest}
            className="flex items-center gap-1.5 text-xs font-semibold px-3.5 py-1.5 rounded-full bg-white border border-teal-accent text-teal-accent hover:bg-teal-accent/10 transition"
          >
            <PlayCircle size={13} />
            Submit for Ingestion
          </button>
        )}
        {doc.status === 'error' && (
          <button
            onClick={onIngest}
            className="flex items-center gap-1.5 text-xs font-semibold px-3.5 py-1.5 rounded-full bg-white border border-gray-300 text-muted-text hover:bg-gray-50 transition"
          >
            <PlayCircle size={13} />
            Retry
          </button>
        )}
      </div>
    </div>
  )
}

function StatusPill({ status }) {
  const config = {
    uploaded: { label: 'Not Yet Ingested', Icon: Clock, cls: 'bg-gray-100 text-muted-text' },
    ingesting: { label: 'Ingesting…', Icon: Loader2, cls: 'bg-indigo-accent/10 text-indigo-accent', spin: true },
    ingested: { label: 'Ingested', Icon: CheckCircle2, cls: 'bg-teal-accent/10 text-teal-accent' },
    error: { label: 'Error', Icon: AlertCircle, cls: 'bg-red-50 text-red-600' },
  }[status] || { label: status, Icon: Clock, cls: 'bg-gray-100 text-muted-text' }

  const { label, Icon, cls, spin } = config

  return (
    <span className={`flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full ${cls}`}>
      <Icon size={12} className={spin ? 'animate-spin' : ''} />
      {label}
    </span>
  )
}