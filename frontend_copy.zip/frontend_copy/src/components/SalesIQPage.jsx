import { useRef, useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { AlertCircle, ShieldAlert } from 'lucide-react'
import { useAuthStore } from '../store/authStore'
import { querySalesIQ } from '../api/client'
import QueryInput from './salesiq/QueryInput'
import InsightPanel from './salesiq/InsightPanel'
import ChartRenderer from './salesiq/ChartRenderer'
import DataSummary from './salesiq/DataSummary'
import ConfidenceBadge from './salesiq/ConfidenceBadge'

export default function SalesIQPage() {
  const sessionToken = useAuthStore((s) => s.sessionToken)
  const role = useAuthStore((s) => s.role)
  const [outputFormat, setOutputFormat] = useState('paragraph') // 'paragraph' | 'bullets' | 'table'
  const chartContainerRef = useRef(null)

  const askMutation = useMutation({
    mutationFn: (query) => querySalesIQ(sessionToken, query),
  })

  const response = askMutation.data
  const error = askMutation.isError ? askMutation.error?.message || 'Query failed' : null

  if (role !== 'mr' && role !== 'flm' && role !== 'slm') {
    return (
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-10 text-center">
        <ShieldAlert size={28} className="mx-auto text-muted-text mb-3" />
        <p className="text-sm text-muted-text">Sales IQ requires MR, FLM, or SLM access.</p>
      </div>
    )
  }

  return (
    <div>
      <p className="text-sm text-muted-text mb-4">Natural language query to smart insight.</p>

      <QueryInput onAsk={(q) => askMutation.mutate(q)} loading={askMutation.isPending} />

      {error && (
        <div className="flex items-center gap-2 rounded-md bg-red-50 border border-red-100 px-3 py-2.5 mb-4">
          <AlertCircle size={14} className="text-red-600 shrink-0" />
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}

      {response && (
        <>
          <div className="flex items-center gap-3 mb-3 flex-wrap">
            <ConfidenceBadge confidence={response.confidence} />
            <label className="flex items-center gap-2 text-sm text-muted-text">
              Output format:
              <select
                value={outputFormat}
                onChange={(e) => setOutputFormat(e.target.value)}
                className="text-sm border border-gray-200 rounded-full px-3 py-1 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
              >
                <option value="paragraph">Paragraph</option>
                <option value="bullets">Bullet points</option>
                <option value="table">Table</option>
              </select>
            </label>
          </div>

          <InsightPanel insight={response.insight} format={outputFormat} />

          <div ref={chartContainerRef} className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 mb-4">
            <ChartRenderer chart={response.chart} />
          </div>

          <DataSummary data_summary={response.data_summary} format={outputFormat} />
        </>
      )}

      {!response && !askMutation.isPending && !error && (
        <p className="text-sm text-muted-text text-center py-8">
          Ask a question above to get started — e.g. "Top 10 brands by sales" or "Sales by month".
        </p>
      )}
    </div>
  )
}