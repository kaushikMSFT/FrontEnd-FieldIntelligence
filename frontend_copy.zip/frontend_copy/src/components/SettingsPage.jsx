import { Settings as SettingsIcon } from 'lucide-react'

export default function SettingsPage() {
  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-10 text-center">
      <SettingsIcon size={28} className="mx-auto text-muted-text mb-3" />
      <p className="text-sm text-muted-text">Settings is coming soon.</p>
    </div>
  )
}