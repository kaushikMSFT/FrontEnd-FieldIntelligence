export default function StatusBadge({ status }) {
  if (status === 'exception') {
    return (
      <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-red-50 text-red-600">
        Exception
      </span>
    )
  }
  return null // AI Ready doctors get a green dot/border instead — see DoctorAccordion
}