import {
  Stethoscope,
  ArrowRight,
  Megaphone,
  List,
  Map,
  BarChart3,
  FileUp,
  Settings as SettingsIcon,
} from 'lucide-react'

const FEATURES = [
  {
    Icon: Megaphone,
    title: 'Objection Intelligence',
    description:
      'AI-generated visit nudges — context, suggestions, and grounded content, built from real DCR, e-detailing, and engagement history.',
    highlighted: true,
  },
  
  {
    Icon: Map,
    title: 'Standard Tour Plan',
    description: 'ML-driven weekly scheduling, generated from historical visit patterns and business rules.',
  },
  {
    Icon: BarChart3,
    title: 'Sales IQ',
    description: 'Natural-language sales analytics — ask a question, get an answer, a chart, and the real data behind it.',
  },
  {
    Icon: FileUp,
    title: 'Product Info',
    description: 'Upload and query real Product Information documents — grounded answers, not generic drug knowledge.',
  },
  
]

export default function LandingPage({ onGetStarted }) {
  return (
    <div className="min-h-screen bg-page-bg">
      <header className="flex items-center justify-between px-8 py-5 border-b border-gray-200 bg-white">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-navy-dark flex items-center justify-center shrink-0">
            <Stethoscope size={16} className="text-white" />
          </div>
          <span className="font-bold text-lg text-navy-text">Field Intelligence</span>
          <span className="text-xs font-medium px-2.5 py-1 rounded-full border border-gray-200 text-muted-text">
            Internal Demo
          </span>
        </div>
        <button
          onClick={onGetStarted}
          className="text-sm font-semibold px-5 py-2 rounded-full bg-navy-dark text-white hover:opacity-90 transition"
        >
          Log in
        </button>
      </header>

      <main className="max-w-5xl mx-auto px-6 pt-16 pb-20 text-center">
        <span className="inline-flex items-center gap-1.5 text-sm font-medium px-4 py-1.5 rounded-full bg-indigo-accent/10 text-indigo-accent mb-8">
          <span className="w-1.5 h-1.5 rounded-full bg-indigo-accent" />
          Powered by Nagarro
        </span>
        <h1 className="text-5xl md:text-6xl font-bold leading-tight text-navy-text mb-3">
          AI Assistant
          <br />
          <span className="text-indigo-accent">for Field Force</span>
        </h1>

        <p className="text-lg text-muted-text max-w-2xl mx-auto mt-6 mb-10 leading-relaxed">
          One platform bringing together visit preparation, tour planning, sales analytics, and product
          knowledge — grounded in your real data, built for how MRs actually work.
        </p>

        <button
          onClick={onGetStarted}
          className="inline-flex items-center gap-2 text-sm font-semibold px-6 py-3 rounded-full bg-navy-dark text-white hover:opacity-90 transition"
        >
          Get Started
          <ArrowRight size={16} />
        </button>
      </main>
      <section className="max-w-5xl mx-auto px-6 pb-24">
        <h2 className="text-2xl font-bold text-navy-text text-center mb-2">Everything a field force needs</h2>
        <p className="text-sm text-muted-text text-center mb-10">
          Six applications, one unified platform — each grounded in real interaction data, not generic AI.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {FEATURES.map(({ Icon, title, description, highlighted }) => (
            <div
              key={title}
              className={`bg-white rounded-lg p-6 border shadow-sm ${
                highlighted ? 'border-indigo-accent/40' : 'border-gray-200'
              }`}
            >
              <div className="w-10 h-10 rounded-full bg-indigo-accent/10 flex items-center justify-center mb-4">
                <Icon size={18} className="text-indigo-accent" />
              </div>
              <h3 className="font-bold text-navy-text mb-1.5">{title}</h3>
              <p className="text-sm text-muted-text leading-relaxed">{description}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}