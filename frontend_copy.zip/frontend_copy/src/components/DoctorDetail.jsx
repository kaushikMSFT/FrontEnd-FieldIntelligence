import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { RefreshCw, ThumbsUp, ThumbsDown, MessageSquare, CheckCircle2, Info } from 'lucide-react'
import { fetchNudge, submitFeedback } from '../api/client'
import StatusBadge from './StatusBadge'

export default function DoctorDetail({ doctor }) {
  const queryClient = useQueryClient()
  const [feedbackText, setFeedbackText] = useState('')
  const [showFeedbackInput, setShowFeedbackInput] = useState(false)

  const {
    data: nudge,
    isLoading,
    isError,
    error,
    refetch,
    isFetching,
  } = useQuery({
    queryKey: ['nudge', doctor.hcp_id],
    queryFn: () => fetchNudge(doctor.hcp_id, 'on_demand'),
    enabled: doctor.status === 'ai_ready',
    retry: false,
  })

  const feedbackMutation = useMutation({
    mutationFn: ({ feedbackType, text }) =>
      submitFeedback(doctor.hcp_id, nudge.id, feedbackType, text),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['nudge', doctor.hcp_id] })
      setFeedbackText('')
      setShowFeedbackInput(false)
    },
  })

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="text-lg font-bold text-navy-text">{doctor.name}</h3>
          <p className="text-sm text-muted-text">{doctor.hcp_id}</p>
        </div>
        <StatusBadge status={doctor.status} />
      </div>

      {doctor.status === 'exception' && <ExceptionCard />}

      {doctor.status === 'ai_ready' && isLoading && (
        <p className="text-sm text-muted-text">Generating nudge…</p>
      )}

      {doctor.status === 'ai_ready' && isError && (
        <div className="rounded-md bg-red-50 border border-red-100 px-4 py-3 text-sm text-red-700">
          Couldn't generate a nudge right now. {error.message}
        </div>
      )}

      {doctor.status === 'ai_ready' && nudge && (
        <div className="space-y-5">
          <div className="flex justify-end">
            <button
              onClick={() => refetch()}
              disabled={isFetching}
              className="flex items-center gap-1.5 text-xs text-muted-text hover:text-navy-text transition disabled:opacity-50"
            >
              <RefreshCw size={13} className={isFetching ? 'animate-spin' : ''} />
              Refresh
            </button>
          </div>

          <section>
            <h4 className="text-xs font-semibold uppercase tracking-wide text-indigo-accent mb-1.5">
              Context
            </h4>
            <p className="text-sm text-navy-text leading-relaxed">{nudge.context_summary}</p>
            {nudge.context_key_signals?.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {nudge.context_key_signals.map((s) => (
                  <span key={s} className="text-xs px-2 py-0.5 rounded-full bg-teal-accent/10 text-teal-accent">
                    {s}
                  </span>
                ))}
              </div>
            )}
          </section>

          <section>
            <h4 className="text-xs font-semibold uppercase tracking-wide text-indigo-accent mb-1.5">
              Topic
            </h4>
            <p className="text-sm font-medium text-navy-text">{nudge.topic_title}</p>
            <p className="text-sm text-muted-text mt-1">{nudge.topic_rationale}</p>
          </section>

          {nudge.content_items?.length > 0 && (
            <section>
              <h4 className="text-xs font-semibold uppercase tracking-wide text-indigo-accent mb-1.5">
                Content
              </h4>
              <ul className="space-y-2">
                {nudge.content_items.map((item, i) => (
                  <li key={i} className="text-sm border border-gray-100 rounded-md px-3 py-2">
                    <p className="font-medium text-navy-text">{item.title}</p>
                    <p className="text-muted-text text-xs mt-0.5">{item.reason}</p>
                  </li>
                ))}
              </ul>
            </section>
          )}

          <FeedbackBar
            nudge={nudge}
            onFeedback={(type, text) => feedbackMutation.mutate({ feedbackType: type, text })}
            feedbackText={feedbackText}
            setFeedbackText={setFeedbackText}
            showFeedbackInput={showFeedbackInput}
            setShowFeedbackInput={setShowFeedbackInput}
            pending={feedbackMutation.isPending}
          />
        </div>
      )}
    </div>
  )
}

function ExceptionCard() {
  // Muted gray treatment, not a warning color — this is a data state, not a fault (PRD Section 6).
  return (
    <div className="flex items-start gap-3 rounded-md border-l-4 border-muted-border bg-gray-50 px-4 py-3">
      <Info size={18} className="text-muted-text mt-0.5 shrink-0" />
      <p className="text-sm text-muted-text">
        Not enough interaction data yet — nudges unavailable.
      </p>
    </div>
  )
}

function FeedbackBar({ nudge, onFeedback, feedbackText, setFeedbackText, showFeedbackInput, setShowFeedbackInput, pending }) {
  return (
    <div className="border-t border-gray-100 pt-4 flex items-center gap-2 flex-wrap">
      <button
        onClick={() => onFeedback('read')}
        disabled={pending}
        className={`flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md border transition ${
          nudge.is_read
            ? 'border-teal-accent text-teal-accent bg-teal-accent/5'
            : 'border-gray-200 text-muted-text hover:border-navy-dark hover:text-navy-text'
        }`}
      >
        <CheckCircle2 size={14} />
        {nudge.is_read ? 'Read' : 'Mark as read'}
      </button>

      <button
        onClick={() => onFeedback('like')}
        disabled={pending}
        className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md border border-gray-200 text-muted-text hover:border-teal-accent hover:text-teal-accent transition"
      >
        <ThumbsUp size={14} />
        Like
      </button>

      <button
        onClick={() => onFeedback('dislike')}
        disabled={pending}
        className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md border border-gray-200 text-muted-text hover:border-red-400 hover:text-red-500 transition"
      >
        <ThumbsDown size={14} />
        Dislike
      </button>

      <button
        onClick={() => setShowFeedbackInput((v) => !v)}
        className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md border border-gray-200 text-muted-text hover:border-indigo-accent hover:text-indigo-accent transition"
      >
        <MessageSquare size={14} />
        Feedback
      </button>

      <span className="ml-auto text-xs text-muted-text">
        Relevance score: <span className="font-semibold text-navy-text">{nudge.relevance_score}</span>
      </span>

      {showFeedbackInput && (
        <div className="w-full flex gap-2 mt-1">
          <input
            type="text"
            value={feedbackText}
            onChange={(e) => setFeedbackText(e.target.value)}
            placeholder="Add a note…"
            className="flex-1 text-sm border border-gray-200 rounded-md px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
          />
          <button
            onClick={() => onFeedback('feedback', feedbackText)}
            disabled={pending || !feedbackText.trim()}
            className="text-xs px-3 py-1.5 rounded-md bg-navy-dark text-white disabled:opacity-40"
          >
            Send
          </button>
        </div>
      )}
    </div>
  )
}
