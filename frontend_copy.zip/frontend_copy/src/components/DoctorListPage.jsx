import { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Users, MousePointerClick, FileText, Clock, Filter } from 'lucide-react'
import { fetchDoctorDashboard } from '../api/client'

export default function DoctorListPage() {
  const { data, isLoading, isError } = useQuery({
    queryKey: ['doctorDashboard'],
    queryFn: fetchDoctorDashboard,
  })

  const [specialtyFilter, setSpecialtyFilter] = useState('all')
  const [productFilter, setProductFilter] = useState('all')
  const [minAvgEd, setMinAvgEd] = useState('')
  const [maxAvgEd, setMaxAvgEd] = useState('')
  const [minRequests, setMinRequests] = useState('')
  const [minCtr, setMinCtr] = useState('')
  const [maxCtr, setMaxCtr] = useState('')

  const specialties = useMemo(
    () => [...new Set((data || []).map((d) => d.specialty).filter(Boolean))].sort(),
    [data]
  )
  const products = useMemo(
    () => [...new Set((data || []).map((d) => d.product).filter(Boolean))].sort(),
    [data]
  )

  const filtered = useMemo(() => {
    if (!data) return []
    return data.filter((d) => {
      if (specialtyFilter !== 'all' && d.specialty !== specialtyFilter) return false
      if (productFilter !== 'all' && d.product !== productFilter) return false
      if (minAvgEd !== '' && d.avg_e_detailing_seconds < Number(minAvgEd)) return false
      if (maxAvgEd !== '' && d.avg_e_detailing_seconds > Number(maxAvgEd)) return false
      if (minRequests !== '' && d.medical_request_count < Number(minRequests)) return false
      if (minCtr !== '' && d.avg_ctr_percent < Number(minCtr)) return false
      if (maxCtr !== '' && d.avg_ctr_percent > Number(maxCtr)) return false
      return true
    })
  }, [data, specialtyFilter, productFilter, minAvgEd, maxAvgEd, minRequests, minCtr, maxCtr])

  if (isLoading) return <p className="text-sm text-muted-text">Loading doctor dashboard…</p>
  if (isError) return <p className="text-sm text-red-600">Couldn't load the dashboard. Is the backend running?</p>

  const avgCtrAcrossFiltered = filtered.length
    ? filtered.reduce((sum, d) => sum + d.avg_ctr_percent, 0) / filtered.length
    : 0
  const avgEdAcrossFiltered = filtered.length
    ? filtered.reduce((sum, d) => sum + d.avg_e_detailing_seconds, 0) / filtered.length
    : 0
  const totalRequests = filtered.reduce((sum, d) => sum + d.medical_request_count, 0)

  return (
    <div>
      <div className="grid grid-cols-4 gap-4 mb-5">
        <StatTile icon={Users} label="Doctors" value={filtered.length} color="indigo" />
        <StatTile icon={MousePointerClick} label="Avg CTR" value={`${avgCtrAcrossFiltered.toFixed(0)}%`} color="teal" />
        <StatTile icon={FileText} label="Medical Requests" value={totalRequests} color="indigo" />
        <StatTile icon={Clock} label="Avg E-detail Time" value={`${avgEdAcrossFiltered.toFixed(0)}s`} color="teal" />
      </div>

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 mb-4">
        <div className="flex items-center gap-1.5 mb-3">
          <Filter size={13} className="text-indigo-accent" />
          <h3 className="text-xs font-semibold uppercase tracking-wide text-indigo-accent">Filters</h3>
        </div>
        <div className="flex flex-wrap items-end gap-4">
          <FilterSelect label="Specialty" value={specialtyFilter} onChange={setSpecialtyFilter} options={specialties} />
          <FilterSelect label="Product" value={productFilter} onChange={setProductFilter} options={products} />
          <RangeFilter
            label="Avg E-detailing time (s)"
            min={minAvgEd}
            max={maxAvgEd}
            onMinChange={setMinAvgEd}
            onMaxChange={setMaxAvgEd}
          />
          <NumberFilter label="Min Medical Requests" value={minRequests} onChange={setMinRequests} />
          <RangeFilter label="Avg CTR (%)" min={minCtr} max={maxCtr} onMinChange={setMinCtr} onMaxChange={setMaxCtr} />
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-gray-100 text-left text-xs font-semibold uppercase tracking-wide text-muted-text">
              <th className="px-3 py-2.5">Name</th>
              <th className="px-3 py-2.5">Email</th>
              <th className="px-3 py-2.5">Specialty</th>
              <th className="px-3 py-2.5">Product</th>
              <th className="px-3 py-2.5">Last Meeting</th>
              <th className="px-3 py-2.5">Next Planned Meeting</th>
              <th className="px-3 py-2.5 text-right">Avg E-detail (s)</th>
              <th className="px-3 py-2.5 text-right"># Med. Requests</th>
              <th className="px-3 py-2.5 text-right">Avg CTR</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((d, i) => (
              <tr
                key={d.hcp_id}
                className={`border-b border-gray-50 transition hover:bg-indigo-accent/5 ${
                  i % 2 === 1 ? 'bg-gray-50/40' : ''
                }`}
              >
                <td className="px-3 py-2 font-medium text-navy-text">{d.name}</td>
                <td className="px-3 py-2 text-muted-text">{d.email_address}</td>
                <td className="px-3 py-2">
                  <Pill color="indigo">{d.specialty}</Pill>
                </td>
                <td className="px-3 py-2">
                  <Pill color="teal">{d.product}</Pill>
                </td>
                <td className="px-3 py-2">
                  <LastMeetingValue date={d.last_meeting_date} />
                </td>
                <td className="px-3 py-2 text-muted-text">{d.next_planned_meeting_date || '—'}</td>
                <td className="px-3 py-2 text-right text-navy-text font-medium">{d.avg_e_detailing_seconds}</td>
                <td className="px-3 py-2 text-right text-navy-text font-medium">{d.medical_request_count}</td>
                <td className="px-3 py-2 text-right">
                  <CtrValue value={d.avg_ctr_percent} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filtered.length === 0 && (
          <div className="px-4 py-8 text-center text-sm text-muted-text">No doctors match your filters.</div>
        )}
      </div>
    </div>
  )
}

const COLOR_CLASSES = {
  indigo: { bg: 'bg-indigo-accent/10', text: 'text-indigo-accent' },
  teal: { bg: 'bg-teal-accent/10', text: 'text-teal-accent' },
}

function StatTile({ icon: Icon, label, value, color }) {
  const c = COLOR_CLASSES[color]
  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 flex items-center gap-3">
      <div className={`w-10 h-10 rounded-full ${c.bg} flex items-center justify-center shrink-0`}>
        <Icon size={18} className={c.text} />
      </div>
      <div>
        <p className="text-xl font-bold text-navy-text leading-tight">{value}</p>
        <p className="text-xs text-muted-text">{label}</p>
      </div>
    </div>
  )
}

function Pill({ color, children }) {
  if (!children) return <span className="text-muted-text">—</span>
  const c = COLOR_CLASSES[color]
  return (
    <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${c.bg} ${c.text}`}>{children}</span>
  )
}

function CtrValue({ value }) {
  const strong = value >= 50
  return (
    <span className={`text-xs font-semibold ${strong ? 'text-teal-accent' : 'text-muted-text'}`}>{value}%</span>
  )
}

function LastMeetingValue({ date }) {
  if (!date) return <span className="text-muted-text">—</span>
  const days = Math.floor((Date.now() - new Date(date).getTime()) / (1000 * 60 * 60 * 24))
  const colorClass = days >= 90 ? 'text-red-600 font-medium' : days >= 45 ? 'text-amber-600 font-medium' : 'text-muted-text'
  return <span className={colorClass}>{date} ({days}d ago)</span>
}

function FilterSelect({ label, value, onChange, options }) {
  return (
    <div>
      <label className="text-xs text-muted-text block mb-1">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="text-sm border border-gray-200 rounded-full px-3.5 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
      >
        <option value="all">All</option>
        {options.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>
    </div>
  )
}

function NumberFilter({ label, value, onChange }) {
  return (
    <div>
      <label className="text-xs text-muted-text block mb-1">{label}</label>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-28 text-sm border border-gray-200 rounded-full px-3.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
      />
    </div>
  )
}

function RangeFilter({ label, min, max, onMinChange, onMaxChange }) {
  return (
    <div>
      <label className="text-xs text-muted-text block mb-1">{label}</label>
      <div className="flex items-center gap-1.5">
        <input
          type="number"
          placeholder="min"
          value={min}
          onChange={(e) => onMinChange(e.target.value)}
          className="w-20 text-sm border border-gray-200 rounded-full px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
        />
        <span className="text-muted-text text-sm">–</span>
        <input
          type="number"
          placeholder="max"
          value={max}
          onChange={(e) => onMaxChange(e.target.value)}
          className="w-20 text-sm border border-gray-200 rounded-full px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
        />
      </div>
    </div>
  )
}