import { useState } from 'react'
import { LogIn, Stethoscope, User, Lock, AlertCircle, Info } from 'lucide-react'
import { login as apiLogin } from '../api/client'
import { useAuthStore } from '../store/authStore'

export default function LoginScreen() {
  const setSession = useAuthStore((s) => s.setSession)
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  async function handleSubmit(e) {
    e.preventDefault()
    setLoading(true)
    setError(null)
    try {
      const { role, session_token, username: signedInUsername } = await apiLogin(username, password)
      setSession(role, session_token, signedInUsername)
    } catch (e) {
      setError(e.status === 401 ? 'Incorrect username or password.' : 'Could not sign in. Is the backend running?')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-page-bg">
      <div className="w-full max-w-md">
        <div className="flex items-center justify-center gap-2 mb-6">
          <div className="w-10 h-10 rounded-full bg-navy-dark flex items-center justify-center shrink-0">
            <Stethoscope size={20} className="text-white" />
          </div>
          <span className="font-bold text-xl text-navy-text">Field Intelligence</span>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
          <h1 className="text-lg font-bold text-navy-text mb-1">Welcome back</h1>
          <p className="text-sm text-muted-text mb-6">Sign in to continue.</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm font-medium text-navy-text block mb-1">Username</label>
              <div className="relative">
                <User size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-text" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  autoComplete="username"
                  className="w-full text-sm border border-gray-200 rounded-md pl-9 pr-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-navy-text block mb-1">Password</label>
              <div className="relative">
                <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-text" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                  className="w-full text-sm border border-gray-200 rounded-md pl-9 pr-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-accent/30"
                />
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 rounded-md bg-red-50 border border-red-100 px-3 py-2">
                <AlertCircle size={14} className="text-red-600 shrink-0" />
                <p className="text-sm text-red-700">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading || !username || !password}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-full bg-navy-dark text-white font-medium hover:opacity-90 disabled:opacity-50 transition"
            >
              <LogIn size={16} />
              {loading ? 'Signing in…' : 'Sign in'}
            </button>
          </form>
        </div>

        <div className="flex items-start gap-2 mt-4 px-1">
          <Info size={13} className="text-muted-text mt-0.5 shrink-0" />
          <p className="text-xs text-muted-text">
            Demo credentials — Medical Rep: <span className="font-medium">MR123 / abcde</span> · Super Admin:{' '}
            <span className="font-medium">SUP123 / abcde</span> · FLM:{' '}
            <span className="font-medium">FLM123 / abcde</span> · SLM:{' '}
            <span className="font-medium">SLM123 / abcde</span>
          </p>
        </div>
      </div>
    </div>
  )
}