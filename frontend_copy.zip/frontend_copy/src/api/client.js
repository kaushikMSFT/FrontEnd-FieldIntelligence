const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'

async function request(path, options = {}) {
  const isFormData = options.body instanceof FormData
  const res = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      ...(isFormData ? {} : { 'Content-Type': 'application/json' }),
      ...options.headers,
    },
  })
  if (!res.ok) {
    const body = await res.json().catch(() => ({}))
    const error = new Error(body.detail || `Request failed: ${res.status}`)
    error.status = res.status
    throw error
  }
  return res.json()
}

export function login(username, password) {
  return request('/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) })
}

export function logout(sessionToken) {
  return request('/auth/logout', {
    method: 'POST',
    headers: { 'x-session-token': sessionToken },
  })
}

export function fetchDoctors() {
  return request('/doctors')
}

export function fetchDoctorDashboard() {
  return request('/doctors/dashboard')
}

export function fetchNudge(hcpId, nudgeType = 'on_demand') {
  return request(`/doctors/${hcpId}/nudge?nudge_type=${nudgeType}`)
}

export function submitFeedback(hcpId, nudgeId, feedbackType, feedbackText = null) {
  return request(`/doctors/${hcpId}/nudge/feedback`, {
    method: 'POST',
    body: JSON.stringify({ nudge_id: nudgeId, feedback_type: feedbackType, feedback_text: feedbackText }),
  })
}

export function fetchAdminConfig(sessionToken) {
  return request('/admin/config', {
    headers: { 'x-session-token': sessionToken },
  })
}

export function updateAdminConfig(sessionToken, config) {
  return request('/admin/config', {
    method: 'PUT',
    headers: { 'x-session-token': sessionToken },
    body: JSON.stringify(config),
  })
}

export function fetchAvailableDrugs() {
  return request('/pi-documents/available-drugs')
}

export function fetchPIDocuments() {
  return request('/pi-documents')
}

export function uploadPIDocument(drugName, file) {
  const formData = new FormData()
  formData.append('drug_name', drugName)
  formData.append('file', file)
  return request('/pi-documents', { method: 'POST', body: formData })
}

export function submitForIngestion(docId) {
  return request(`/pi-documents/${docId}/ingest`, { method: 'POST' })
}

export function generateTourPlan(historyFile, syntheticFile, mrStaffId) {
  const formData = new FormData()
  formData.append('history', historyFile)
  formData.append('synthetic', syntheticFile)
  if (mrStaffId) formData.append('mr_staff_id', mrStaffId)
  return request('/tour-plan/generate', { method: 'POST', body: formData })
}

export function fetchTourPlanStatus(runId) {
  return request(`/tour-plan/status/${runId}`)
}

export function fetchTourPlanEntries(runId) {
  return request(`/tour-plan/${runId}`)
}

export function fetchLatestTourPlanRun() {
  return request('/tour-plan/latest/run')
}

export function fetchDefaultMr() {
  return request('/tour-plan/default-mr')
}

export function querySalesIQ(sessionToken, query) {
  return request('/sales-iq/query', {
    method: 'POST',
    headers: { 'x-session-token': sessionToken },
    body: JSON.stringify({ query }),
  })
}

export function downloadTourPlanUrl(runId) {
  return `${API_BASE_URL}/tour-plan/${runId}/download`
}

export function fetchIngestedDrugs() {
  return request('/pi-documents/ingested-drugs')
}

export function askPIQuestion(drugName, question) {
  return request('/pi-documents/ask', {
    method: 'POST',
    body: JSON.stringify({ drug_name: drugName, question }),
  })
}