/**
 * Format helpers: INR currency (2 decimals), number display.
 * Sales amounts are displayed in Rupee (₹), not Dollar.
 */

const AMOUNT_COLUMN_PATTERNS = [
  /amt$/i, /amount/i, /value/i, /sale_amt/i, /net_value/i,
  /invoice_value/i, /total_bill/i, /actual_amount/i, /cost/i,
  /bonus_amt/i, /sample_amt/i, /return_amt/i, /pts_value/i,
];

export function isAmountColumn(columnName) {
  if (!columnName || typeof columnName !== 'string') return false;
  return AMOUNT_COLUMN_PATTERNS.some((pat) => pat.test(columnName));
}

/** Format number as Indian Rupee: ₹1,23,456.78 (2 decimal places). Always use ₹, never $. */
export function formatCurrencyINR(value) {
  if (value == null || value === '' || Number.isNaN(Number(value))) return '—';
  const num = Number(value);
  const formatted = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(num);
  // Force Rupee: some environments still show $; replace any currency symbol with ₹
  const withRupee = formatted.replace(/^\s*[\$€£¥]\s*|^\s*[A-Z]{3}\s*/i, '₹ ').trim();
  if (withRupee.startsWith('₹')) return withRupee;
  return '₹ ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(num);
}

/** Format cell for display: use INR for amount columns, else string */
export function formatCellValue(value, columnName) {
  if (value == null || value === '') return '—';
  if (isAmountColumn(columnName) && !Number.isNaN(Number(value))) {
    const num = Number(value);
    return new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(num);
  }
  return String(value);
}
